import { ChangeDetectionStrategy, Component, DestroyRef, HostListener, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EMPTY, Observable, catchError, distinctUntilChanged, expand, finalize, map, of, switchMap, tap, throwError, toArray } from 'rxjs';
import { AuthService } from '@core/services/auth.service';
import { ProductCatalogService } from '@core/services/product-catalog.service';
import { ProductImageDisplayService } from '@core/services/product-image-display.service';
import { S3FileUpload, S3ImageService, VARIANT_IMAGE_FOLDER } from '@core/services/s3-image.service';
import { ToastService } from '@core/services/toast.service';
import { variantImageSource } from '@features/products/components/product-variant-selector/product-variant-selector';
import { SellerOnboardingService } from '@features/seller/services/seller-onboarding.service';
import { Button } from '@shared/components/button/button';
import { Dialog } from '@shared/components/dialog/dialog';
import { Input } from '@shared/components/input/input';
import { Pagination } from '@shared/components/pagination/pagination';
import { SearchableSelect, SearchableSelectOption } from '@shared/components/searchable-select/searchable-select';
import { Select } from '@shared/components/select/select';
import { LoadingSpinner } from '@shared/components/loading-spinner/loading-spinner';
import { PaginatedResponse, Product } from '@shared/models';
import {
  ProductVariantLookup,
  ProductVariantLookupOption,
  ProductVariant,
  ProductVariantInsertPayload,
  ProductVariantPage,
  ProductVariantService,
  ProductVariantUpdatePayload,
} from '../../services/product-variant.service';

const PAGE_SIZE = 5;
// CHANGED (new): a Seller's listing page size (LIMIT=10); the Admin listing keeps PAGE_SIZE (LIMIT=5).
const SELLER_PAGE_SIZE = 10;
const PRODUCT_PAGE_SIZE = 100;
const MAX_VARIANT_IMAGE_SIZE = 5 * 1024 * 1024;
// CHANGED (new): the image types the S3 upload API accepts.
const VARIANT_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp'];
const VARIANT_SELLER_ID = 1;
const VARIANT_SELLER_NAME = 'Arun Kumar';
const VARIANT_UPDATE_SELLER_ID = 1;

type VariantLookupState = {
  status: 'idle' | 'loading' | 'success' | 'error';
  options: ProductVariantLookupOption[];
  error: string | null;
};

const EMPTY_LOOKUP_STATE: VariantLookupState = { status: 'idle', options: [], error: null };
const VARIANT_LOOKUP_NAMES: readonly ProductVariantLookup[] = ['colours', 'sizes', 'materials'];
const EMPTY_VARIANT_DIMENSION_VALUES = new Set(['—', '-', '_']);

function optionalVariantDimension(value: string): string {
  const normalized = value.trim();
  return EMPTY_VARIANT_DIMENSION_VALUES.has(normalized) ? '' : normalized;
}

function hasVariantDimensionSelection(value: string, id: number | null): boolean {
  const rawValue = value.trim();
  return rawValue ? optionalVariantDimension(rawValue) !== '' : id !== null;
}

@Component({
  selector: 'app-product-variants',
  // CHANGED: SearchableSelect for the Add Variant product dropdown.
  imports: [DecimalPipe, FormsModule, Button, Dialog, Input, LoadingSpinner, Pagination, SearchableSelect, Select],
  // CHANGED (new): variant images from S3 (signed URLs), shared with All Products and the Home page.
  providers: [ProductImageDisplayService],
  templateUrl: './product-variants.html',
  styleUrl: './product-variants.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductVariants {
  private readonly variantService = inject(ProductVariantService);
  private readonly productCatalog = inject(ProductCatalogService);
  private readonly sellerOnboarding = inject(SellerOnboardingService);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(AuthService);
  private readonly destroyRef = inject(DestroyRef);
  // CHANGED (new): variant images are uploaded to S3 ("variants/<unique file name>") and shown from their key.
  private readonly s3Images = inject(S3ImageService);
  private readonly imageUpload = new S3FileUpload(this.s3Images, VARIANT_IMAGE_FOLDER);
  protected readonly variantImages = inject(ProductImageDisplayService);
  // CHANGED (new): a Seller lists only their own variants; Admins (and any other role) keep the full listing.
  private readonly isSeller = computed(
    () => this.auth.user()?.userType?.trim().toUpperCase() === 'SELLER',
  );
  protected readonly variants = signal<ProductVariant[]>([]);
  protected readonly products = signal<Product[]>([]);
  protected readonly productsStatus = signal<'idle' | 'loading' | 'success' | 'error'>('idle');
  protected readonly productsError = signal<string | null>(null);
  // CHANGED (new): Add Variant product dropdown. Its list scrolls inside the dialog (a native <select> list
  // is drawn by the browser and runs off the screen with many products) and can be searched.
  protected readonly productOptions = computed<SearchableSelectOption[]>(() =>
    this.products().map((product) => ({ label: product.name, value: product.id })),
  );
  protected readonly productPlaceholder = computed(() => {
    if (this.productsStatus() === 'loading') return 'Loading products…';
    if (this.productsStatus() === 'success' && !this.products().length) return 'No products available';
    return 'Select product';
  });
  protected readonly loadStatus = signal<'loading' | 'success' | 'error'>('loading');
  protected readonly loadError = signal<string | null>(null);
  protected readonly page = signal(1);
  // CHANGED: depends on the role (Admin 5, Seller 10 per page).
  protected readonly pageSize = computed(() => (this.isSeller() ? SELLER_PAGE_SIZE : PAGE_SIZE));
  private readonly retryCount = signal(0);
  private readonly totalVariants = signal<number | null>(null);
  private readonly hasNextPage = signal(false);
  private activePage: number | null = null;
  protected readonly totalCount = computed(() => this.totalVariants());
  protected readonly totalPages = computed(() => {
    const total = this.totalVariants();
    return total === null ? undefined : Math.ceil(total / this.pageSize());
  });
  protected readonly canGoNext = computed(() =>
    this.totalPages() === undefined ? this.hasNextPage() : this.page() < this.totalPages()!,
  );
  private readonly pageRequest = computed(() => ({ page: this.page(), retry: this.retryCount() }));
  protected readonly dialog = signal<'add' | 'edit' | 'delete' | null>(null);
  protected readonly selected = signal<ProductVariant | null>(null);
  protected readonly menu = signal<string | null>(null);
  protected readonly menuPosition = signal<{ top: number; right: number } | null>(null);
  protected readonly form = signal({ productId: '', name: '', sku: '', barcode: '', size: '', sizeId: null as number | null, color: '', colorId: null as number | null, material: '', materialId: null as number | null, weight: '', price: '', stock: '', status: 'ACTIVE' });
  protected readonly error = signal(false);
  protected readonly imageError = signal('');
  protected readonly selectedImage = signal<File | null>(null);
  // CHANGED (new): object URL of the selected image (shown before it is uploaded), and the upload in progress.
  protected readonly imagePreview = signal<string | null>(null);
  protected readonly uploadingImage = signal(false);
  protected readonly isSubmitting = signal(false);
  protected readonly variantLookups = signal<Record<ProductVariantLookup, VariantLookupState>>({
    colours: { ...EMPTY_LOOKUP_STATE },
    sizes: { ...EMPTY_LOOKUP_STATE },
    materials: { ...EMPTY_LOOKUP_STATE },
  });

  constructor() {
    toObservable(this.pageRequest)
      .pipe(
        distinctUntilChanged((previous, current) =>
          previous.page === current.page && previous.retry === current.retry,
        ),
        switchMap(({ page }) => {
          if (this.activePage !== page) {
            this.activePage = page;
            this.variants.set([]);
            this.totalVariants.set(null);
            this.hasNextPage.set(false);
          }
          this.loadStatus.set('loading');
          this.loadError.set(null);
          // CHANGED: the request depends on the role (see loadVariantPage); the response handling is shared.
          return this.loadVariantPage(page).pipe(
            tap((result) => {
              this.variants.set(result.items);
              // CHANGED (new): one URL request per distinct S3 image key on the page.
              this.variantImages.show(result.items.map(variantImageSource));
              this.totalVariants.set(result.total ?? null);
              this.hasNextPage.set(result.hasNext);
              this.loadStatus.set('success');
            }),
            catchError((error: unknown) => {
              this.loadError.set(this.variantService.getErrorMessage(error));
              this.loadStatus.set('error');
              return EMPTY;
            }),
          );
        }),
        takeUntilDestroyed(),
      )
      .subscribe();
    // CHANGED (new): releases the preview's object URL when the page closes.
    this.destroyRef.onDestroy(() => this.setSelectedImage(null));
  }

  /** The variant's own image (signed S3 URL or legacy /uploads URL), or null for the placeholder. */
  // CHANGED (new)
  protected variantImage(variant: ProductVariant): string | null {
    return this.variantImages.src(variantImageSource(variant));
  }

  // CHANGED (new)
  protected variantImageLoading(variant: ProductVariant): boolean {
    return this.variantImages.loading(variantImageSource(variant));
  }

  // CHANGED (new): one fresh URL for an S3 image that fails to display, then the placeholder.
  protected variantImageFailed(variant: ProductVariant, src: string): void {
    this.variantImages.failed(variantImageSource(variant), src);
  }

  /**
   * Admin: `product_variant/get?LIMIT=5&OFFSET=…` (unchanged).
   * Seller: `product_variant/get?PRODUCT_ID=-1&VARIANT_ID=-1&SELLER_ID=<own SELLER_ID>&LIMIT=10&OFFSET=…`.
   * The SELLER_ID comes from the signed-in session (the access token's SELLER_ID claim); when the token has
   * none it is resolved from the seller's record (cached per session). Without a SELLER_ID no request is
   * sent, so a Seller never gets the unfiltered listing. Rows of another seller are never shown.
   */
  // CHANGED (new): role-based Variant listing request.
  private loadVariantPage(page: number): Observable<ProductVariantPage> {
    if (!this.isSeller()) return this.variantService.loadPage(page, PAGE_SIZE);

    return this.currentSellerId().pipe(
      switchMap((sellerId) =>
        this.variantService.loadPage(page, SELLER_PAGE_SIZE, sellerId).pipe(
          map((result) => ({
            ...result,
            items: result.items.filter((variant) => variant.sellerId === null || variant.sellerId === sellerId),
          })),
        ),
      ),
    );
  }

  /**
   * The signed-in Seller's SELLER_ID: the access token's SELLER_ID claim, else the seller's record
   * (cached per session). Errors when the user has no seller account.
   */
  // CHANGED (new): shared by the Seller's variant listing and Add Variant product dropdown.
  private currentSellerId(): Observable<number> {
    const sessionSellerId = this.auth.sellerId();
    return sessionSellerId !== undefined ? of(sessionSellerId) : this.sellerOnboarding.getCurrentSellerId();
  }

  /**
   * Products for the Add Variant dropdown, every page of PRODUCT_PAGE_SIZE.
   * Admin: `products/get?PRODUCT_ID=-1&LIMIT=100&OFFSET=…` (unchanged).
   * Seller: the All Products listing request with the seller's SELLER_ID and STATUS=ACTIVE
   * (`products/get?PRODUCT_ID=-1&CATEGORY_ID=-1&BRAND_ID=-1&SELLER_ID=<own>&STATUS=ACTIVE&LIMIT=100&OFFSET=…`),
   * so only the seller's own active products can be picked. The API returns a row per product variant, so each
   * product is listed once.
   */
  // CHANGED (new): role-based product source for the Add Variant dropdown.
  // CHANGED: the Seller's dropdown sends STATUS=ACTIVE and never lists an inactive product.
  private loadDropdownProducts(): Observable<Product[]> {
    if (!this.isSeller()) return this.allProductPages((page) => this.productCatalog.loadPage(page, PRODUCT_PAGE_SIZE));

    return this.currentSellerId().pipe(
      switchMap((sellerId) =>
        this.allProductPages((page) =>
          this.productCatalog.loadListingPage({ sellerId, status: 'ACTIVE' }, page, PRODUCT_PAGE_SIZE),
        ).pipe(
          map((products) =>
            products.filter(
              (product, index) =>
                (product.sellerId === undefined || product.sellerId === sellerId) &&
                product.isActive !== false &&
                products.findIndex((other) => other.id === product.id) === index,
            ),
          ),
        ),
      ),
    );
  }

  /** Requests page 1, then each next page while the API reports one, and returns all their products. */
  private allProductPages(loadPage: (page: number) => Observable<PaginatedResponse<Product>>): Observable<Product[]> {
    return loadPage(1).pipe(
      expand((result, index) => (result.hasNext ? loadPage(index + 2) : EMPTY)),
      map((result) => result.items),
      toArray(),
      map((pages) => pages.flat()),
    );
  }

  protected retryLoad(): void {
    this.retryCount.update((count) => count + 1);
  }

  protected toggleMenu(id: string, event: MouseEvent): void {
    event.stopPropagation();
    if (this.menu() === id) {
      this.menu.set(null);
      this.menuPosition.set(null);
      return;
    }

    const button = event.currentTarget;
    if (!(button instanceof HTMLElement)) return;
    const bounds = button.getBoundingClientRect();
    const menuHeight = 76;
    const top = window.innerHeight - bounds.bottom >= menuHeight + 8
      ? bounds.bottom + 4
      : Math.max(8, bounds.top - menuHeight - 4);
    this.menuPosition.set({
      top,
      right: Math.max(8, window.innerWidth - bounds.right),
    });
    this.menu.set(id);
  }

  @HostListener('document:click', ['$event'])
  protected closeMenuOutside(event: MouseEvent): void {
    const target = event.target;
    if (target instanceof Element && target.closest('.action-cell')) return;
    this.menu.set(null);
    this.menuPosition.set(null);
  }

  protected retryProducts(): void {
    this.loadProducts();
  }

  private loadProducts(): void {
    if (this.productsStatus() === 'loading') return;
    this.productsStatus.set('loading');
    this.productsError.set(null);
    // CHANGED: the product source depends on the role (see loadDropdownProducts); the states below are shared.
    this.loadDropdownProducts().pipe(
      tap((products) => {
        this.products.set(products);
        this.productsStatus.set('success');
      }),
      catchError((error: unknown) => {
        const message = this.productCatalog.getErrorMessage(error);
        this.productsError.set(message);
        this.productsStatus.set('error');
        this.toast.showError(message);
        return EMPTY;
      }),
      takeUntilDestroyed(this.destroyRef),
    ).subscribe();
  }

  private loadVariantLookups(): void {
    for (const lookup of VARIANT_LOOKUP_NAMES) {
      if (this.variantLookups()[lookup].status === 'loading' || this.variantLookups()[lookup].status === 'success') {
        continue;
      }
      this.variantLookups.update((states) => ({
        ...states,
        [lookup]: { ...states[lookup], status: 'loading', error: null },
      }));
      this.variantService
        .loadLookup(lookup)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (options) =>
            this.variantLookups.update((states) => ({
              ...states,
              [lookup]: { status: 'success', options, error: null },
            })),
          error: (error: unknown) =>
            this.variantLookups.update((states) => ({
              ...states,
              [lookup]: {
                status: 'error',
                options: [],
                error: this.variantService.getErrorMessage(error),
              },
            })),
        });
    }
  }

  protected retryVariantLookup(lookup: ProductVariantLookup): void {
    this.variantLookups.update((states) => ({
      ...states,
      [lookup]: { ...EMPTY_LOOKUP_STATE },
    }));
    this.loadVariantLookups();
  }

  protected hasLookupValue(lookup: ProductVariantLookup, value: string): boolean {
    return !!value && !this.variantLookups()[lookup].options.some((option) => option.name === value);
  }

  private lookupId(lookup: ProductVariantLookup, value: string): number | null {
    const option = this.variantLookups()[lookup].options.find(
      (entry) => entry.id === value || entry.name === value,
    );
    const id = Number(option?.id);
    return Number.isSafeInteger(id) && id > 0 ? id : null;
  }

  protected sizeDropdownValue(): string {
    if (this.dialog() === 'add') {
      const sizeId = this.form().sizeId;
      return sizeId === null ? '' : String(sizeId);
    }
    const size = this.form().size;
    return this.variantLookups().sizes.options.find((option) => option.name === size)?.id ?? size;
  }

  protected setSizeField(event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLSelectElement)) return;
    const value = target.value;
    if (this.dialog() === 'add') {
      const sizeId = Number(value);
      this.form.update((form) => ({
        ...form,
        sizeId: value && Number.isSafeInteger(sizeId) && sizeId > 0 ? sizeId : null,
      }));
      return;
    }
    const size = this.variantLookups().sizes.options.find((option) => option.id === value)?.name ?? value;
    this.form.update((form) => ({
      ...form,
      size,
      sizeId: this.lookupId('sizes', value),
    }));
  }

  protected colorDropdownValue(): string {
    if (this.dialog() === 'add') {
      const colorId = this.form().colorId;
      return colorId === null ? '' : String(colorId);
    }
    const color = this.form().color;
    return this.variantLookups().colours.options.find((option) => option.name === color)?.id ?? color;
  }

  protected setColorField(event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLSelectElement)) return;
    const value = target.value;
    const option = this.variantLookups().colours.options.find((entry) => entry.id === value);
    if (this.dialog() === 'add') {
      const colorId = Number(value);
      this.form.update((form) => ({
        ...form,
        color: option?.name ?? '',
        colorId: value && Number.isSafeInteger(colorId) && colorId > 0 ? colorId : null,
      }));
      return;
    }
    this.form.update((form) => ({
      ...form,
      color: option?.name ?? value,
      colorId: this.lookupId('colours', value),
    }));
  }

  protected materialDropdownValue(): string {
    if (this.dialog() === 'add') {
      const materialId = this.form().materialId;
      return materialId === null ? '' : String(materialId);
    }
    const material = this.form().material;
    return this.variantLookups().materials.options.find((option) => option.name === material)?.id ?? material;
  }

  protected setMaterialField(event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLSelectElement)) return;
    const value = target.value;
    const option = this.variantLookups().materials.options.find((entry) => entry.id === value);
    if (this.dialog() === 'add') {
      const materialId = Number(value);
      this.form.update((form) => ({
        ...form,
        material: option?.name ?? '',
        materialId: value && Number.isSafeInteger(materialId) && materialId > 0 ? materialId : null,
      }));
      return;
    }
    this.form.update((form) => ({
      ...form,
      material: option?.name ?? value,
      materialId: this.lookupId('materials', value),
    }));
  }

  protected openAdd(): void {
    this.selected.set(null);
    this.form.set({ productId: '', name: '', sku: '', barcode: '', size: '', sizeId: null, color: '', colorId: null, material: '', materialId: null, weight: '', price: '', stock: '', status: 'ACTIVE' });
    this.error.set(false);
    this.imageError.set('');
    this.setSelectedImage(null);
    this.dialog.set('add');
    if (this.productsStatus() !== 'success') this.loadProducts();
    this.loadVariantLookups();
  }
  protected openEdit(row: ProductVariant): void {
    this.selected.set(row);
    this.form.set({ productId: '', name: row.name, sku: row.sku, barcode: row.barcode, size: row.size, sizeId: null, color: row.color, colorId: null, material: row.material, materialId: null, weight: row.weight, price: String(row.price), stock: String(row.stock), status: row.status });
    this.error.set(false);
    this.imageError.set('');
    this.setSelectedImage(null);
    this.dialog.set('edit');
    this.menu.set(null);
    this.menuPosition.set(null);
    this.loadVariantLookups();
  }
  protected openDelete(row: ProductVariant): void {
    this.selected.set(row);
    this.dialog.set('delete');
    this.menu.set(null);
    this.menuPosition.set(null);
  }
  protected close(): void {
    if (this.isSubmitting()) return;
    this.dialog.set(null);
    this.error.set(false);
    this.imageError.set('');
    this.setSelectedImage(null);
  }
  protected setField(key: keyof ReturnType<typeof this.form>, event: Event): void {
    const target = event.target;
    if (target instanceof HTMLInputElement || target instanceof HTMLSelectElement) this.form.update((v) => ({ ...v, [key]: target.value }));
  }
  // CHANGED (new): the searchable product dropdown emits the product ID itself (not a change event).
  protected setProductId(productId: string): void {
    this.form.update((v) => ({ ...v, productId }));
  }
  // CHANGED: only the types the S3 API accepts (PNG, JPG, WEBP; was any image/*), no empty file, and a preview.
  // The image's unique S3 file name is fixed here and used by its upload.
  protected onImageChange(event: Event): void {
    const target = event.target;
    const file = target instanceof HTMLInputElement ? target.files?.[0] ?? null : null;
    this.imageError.set('');
    if (file && !VARIANT_IMAGE_TYPES.includes(file.type)) {
      this.setSelectedImage(null);
      this.imageError.set('Choose a PNG, JPG, or WEBP image.');
      return;
    }
    if (file && file.size === 0) {
      this.setSelectedImage(null);
      this.imageError.set('The selected image is empty. Choose another file.');
      return;
    }
    if (file && file.size > MAX_VARIANT_IMAGE_SIZE) {
      this.setSelectedImage(null);
      this.imageError.set('The image must be 5 MB or smaller.');
      return;
    }
    if (file) this.imageUpload.fileName(file);
    this.setSelectedImage(file);
  }

  /** The browser could not show the selected file, so it is not a usable image. */
  // CHANGED (new)
  protected previewFailed(): void {
    this.setSelectedImage(null);
    this.imageError.set('This file could not be read as an image. Choose another file.');
  }

  // CHANGED (new): keeps the preview object URL in step with the selected file.
  private setSelectedImage(file: File | null): void {
    const previous = this.imagePreview();
    if (previous) URL.revokeObjectURL(previous);
    this.imagePreview.set(file && typeof URL.createObjectURL === 'function' ? URL.createObjectURL(file) : null);
    this.selectedImage.set(file);
  }

  /**
   * The variant image's S3 key: uploads the new image ("variants/<its unique file name>"), or reuses the key of an
   * earlier upload of the same file (e.g. when the upload worked but saving the variant failed).
   */
  // CHANGED (new)
  private uploadVariantImage(file: File): Observable<string> {
    if (this.imageUpload.uploadedKey(file)) return this.imageUpload.upload(file);
    this.uploadingImage.set(true);
    return this.imageUpload.upload(file).pipe(
      catchError((error: unknown) => {
        const message = this.s3Images.uploadErrorMessage(error, 'The variant image');
        this.imageError.set(message);
        return throwError(() => new Error(message));
      }),
      finalize(() => this.uploadingImage.set(false)),
    );
  }
  protected save(): void {
    if (this.isSubmitting()) return;
    const v = this.form();
    if (this.dialog() === 'add') {
      const productId = Number(v.productId);
      const weight = v.weight.trim() ? Number(v.weight) : null;
      const price = Number(v.price);
      const stock = Number(v.stock);
      const imageFile = this.selectedImage();
      const selectedProduct = this.products().find((product) => product.id === v.productId);
      if (
        !Number.isSafeInteger(productId) || productId <= 0 ||
        !v.name.trim() ||
        (v.colorId !== null && (!Number.isSafeInteger(v.colorId) || v.colorId <= 0)) ||
        (v.sizeId !== null && (!Number.isSafeInteger(v.sizeId) || v.sizeId <= 0)) ||
        (v.materialId !== null && (!Number.isSafeInteger(v.materialId) || v.materialId <= 0)) ||
        !Number.isFinite(price) || price < 0 ||
        !Number.isSafeInteger(stock) || stock < 0 ||
        (weight !== null && (!Number.isFinite(weight) || weight < 0)) ||
        !imageFile
      ) {
        this.error.set(true);
        return;
      }
      if (!selectedProduct) {
        this.error.set(true);
        return;
      }

      // CHANGED: VARIANT_IMAGE is the S3 key of the uploaded image (set below); it used to be the local file name
      // of a file that was never uploaded.
      const payload: Omit<ProductVariantInsertPayload, 'CREATED_BY'> = {
        VARIANT_NAME: v.name.trim(),
        BARCODE: v.barcode.trim() || null,
        ...(v.sizeId !== null && hasVariantDimensionSelection(v.size, v.sizeId) ? { SIZE_ID: v.sizeId } : {}),
        ...(v.colorId !== null && hasVariantDimensionSelection(v.color, v.colorId) ? { COLOUR_ID: v.colorId } : {}),
        ...(v.materialId !== null && hasVariantDimensionSelection(v.material, v.materialId) ? { MATERIAL_ID: v.materialId } : {}),
        WEIGHT: weight,
        PRICE: price,
        STOCK_QUANTITY: stock,
        VARIANT_IMAGE: '',
        PRODUCT_ID: productId,
        SELLER_ID: VARIANT_SELLER_ID,
        SELLER_NAME: VARIANT_SELLER_NAME,
      };

      this.error.set(false);
      this.isSubmitting.set(true);
      this.sellerOnboarding.getSellerIdForCurrentUser(payload.SELLER_ID).pipe(
        // CHANGED: the image is uploaded first; the variant is created only with its S3 key.
        switchMap((sellerId) =>
          this.uploadVariantImage(imageFile).pipe(
            switchMap((imageKey) =>
              this.variantService.insertVariant({ ...payload, VARIANT_IMAGE: imageKey, SELLER_ID: sellerId }),
            ),
          ),
        ),
        tap((message) => {
          this.toast.showSuccess(message);
          this.dialog.set(null);
          this.setSelectedImage(null);
          if (this.page() === 1) this.retryLoad();
          else this.page.set(1);
        }),
        catchError((error: unknown) => {
          this.toast.showError(this.variantService.getErrorMessage(error));
          return EMPTY;
        }),
        finalize(() => this.isSubmitting.set(false)),
        takeUntilDestroyed(this.destroyRef),
      ).subscribe();
      return;
    }

    const selected = this.selected();
    const variantId = Number(selected?.id);
    const productId = selected?.productId;
    const sellerName = selected?.sellerName?.trim();
    const weight = v.weight.trim() ? Number(v.weight) : null;
    const price = Number(v.price);
    const stock = Number(v.stock);
    const imageFile = this.selectedImage();
    // CHANGED: a new image is uploaded to S3 (its key is sent); otherwise the saved VARIANT_IMAGE is kept as is.
    // (A new image used to be sent as its local file name.)
    const imageName = imageFile ? this.imageUpload.fileName(imageFile) : selected?.imagePath ?? '';
    const size = optionalVariantDimension(v.size);
    const color = optionalVariantDimension(v.color);
    const material = optionalVariantDimension(v.material);
    const sizeId = size ? v.sizeId ?? this.lookupId('sizes', size) : null;
    const colorId = color ? v.colorId ?? this.lookupId('colours', color) : null;
    const materialId = material ? v.materialId ?? this.lookupId('materials', material) : null;
    if (
      !selected ||
      !Number.isSafeInteger(variantId) || variantId <= 0 ||
      productId === null || productId === undefined || !Number.isSafeInteger(productId) || productId <= 0 ||
      !sellerName ||
      !v.name.trim() || !v.status.trim() || !imageName.trim() ||
      !Number.isFinite(price) || price < 0 ||
      !Number.isSafeInteger(stock) || stock < 0 ||
      (weight !== null && (!Number.isFinite(weight) || weight < 0))
    ) {
      this.error.set(true);
      if (selected && (productId === null || productId === undefined || productId <= 0)) {
        this.toast.showError('The selected variant does not include a valid product ID.');
      } else if (selected && !sellerName) {
        this.toast.showError('The selected variant does not include a seller name.');
      } else if (selected && !imageName.trim()) {
        this.toast.showError('The selected variant does not include an image.');
      }
      return;
    }
    const payload: Omit<ProductVariantUpdatePayload, 'CREATED_BY'> = {
      VARIANT_ID: variantId,
      PRODUCT_ID: productId,
      VARIANT_NAME: v.name.trim(),
      BARCODE: v.barcode.trim() || null,
      ...(size ? sizeId !== null ? { SIZE_ID: sizeId } : { SIZE: size } : {}),
      ...(color ? colorId !== null ? { COLOR_ID: colorId } : { COLOR: color } : {}),
      ...(materialId !== null
        ? { MATERIAL_ID: materialId }
        : material ? { MATERIAL: material } : {}),
      WEIGHT: weight,
      PRICE: price,
      STOCK_QUANTITY: stock,
      VARIANT_IMAGE: imageName,
      SELLER_ID: VARIANT_UPDATE_SELLER_ID,
      SELLER_NAME: sellerName,
      STATUS: v.status.trim(),
    };

    this.error.set(false);
    this.isSubmitting.set(true);
    this.sellerOnboarding.getSellerIdForCurrentUser(payload.SELLER_ID).pipe(
      switchMap((sellerId) =>
        (imageFile ? this.uploadVariantImage(imageFile) : of(payload.VARIANT_IMAGE)).pipe(
          switchMap((imageKey) =>
            this.variantService.updateVariant({ ...payload, VARIANT_IMAGE: imageKey, SELLER_ID: sellerId }),
          ),
        ),
      ),
      tap((message) => {
        this.toast.showSuccess(message);
        this.dialog.set(null);
        this.setSelectedImage(null);
        if (this.page() === 1) this.retryLoad();
        else this.page.set(1);
      }),
      catchError((error: unknown) => {
        this.toast.showError(this.variantService.getErrorMessage(error));
        return EMPTY;
      }),
      finalize(() => this.isSubmitting.set(false)),
      takeUntilDestroyed(this.destroyRef),
    ).subscribe();
  }
  protected confirmDelete(): void {
    if (this.isSubmitting()) return;
    const selected = this.selected();
    const variantId = Number(selected?.id);
    const productId = selected?.productId;
    if (!selected || !Number.isSafeInteger(variantId) || variantId <= 0) {
      this.toast.showError('The selected variant does not include a valid variant ID.');
      return;
    }
    if (productId === null || productId === undefined || !Number.isSafeInteger(productId) || productId <= 0) {
      this.toast.showError('The selected variant does not include a valid product ID.');
      return;
    }

    this.isSubmitting.set(true);
    this.variantService.deleteVariant({ PRODUCT_ID: productId, VARIANT_ID: variantId }).pipe(
      tap((message) => {
        this.toast.showSuccess(message);
        this.variants.update((variants) => variants.filter((variant) => variant.id !== selected.id));
        this.totalVariants.update((total) => total === null ? null : Math.max(0, total - 1));
        this.selected.set(null);
        this.dialog.set(null);
        if (this.page() > 1 && this.variants().length === 0) {
          this.page.update((page) => page - 1);
        } else {
          this.retryLoad();
        }
      }),
      catchError((error: unknown) => {
        this.toast.showError(this.variantService.getErrorMessage(error));
        return EMPTY;
      }),
      finalize(() => this.isSubmitting.set(false)),
      takeUntilDestroyed(this.destroyRef),
    ).subscribe();
  }
  protected setPage(n: number): void {
    const lastPage = this.totalPages();
    if (Number.isSafeInteger(n) && n >= 1 && (lastPage === undefined || n <= lastPage)) this.page.set(n);
  }
}
