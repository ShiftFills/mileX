import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthService } from '@core/services/auth.service';
import { ToastService } from '@core/services/toast.service';
import {
  ReturnReasonOption,
  ReturnRequestRow,
  ReturnRequestsPage,
  ShipmentTracking,
  StatusOption,
} from '@shared/models';
import { OrderService } from '@features/orders/services/order.service';
import { SellerOnboardingService } from '@features/seller/services/seller-onboarding.service';
import { Observable, of, throwError } from 'rxjs';
import { ReturnRequest } from './return-request';

const orderStatuses: StatusOption[] = [
  { id: 24, label: 'PENDING' },
  { id: 25, label: 'APPROVED' },
  // CHANGED (new)
  { id: 26, label: 'REJECTED' },
];
// CHANGED: the shipping statuses (shipping_status/get) only name the return types (RETURN/REFUND, RETURN/REPLACE) of
// RETURN_OPTION.
const shippingStatuses: StatusOption[] = [
  { id: 28, label: 'RETURN/REFUND' },
  { id: 27, label: 'RETURN/REPLACE' },
  { id: 4, label: 'DELIVERED' },
];
// CHANGED (new): the return statuses (return_status): the Review's Return status options, by RETURN_STATUS_ID.
const returnStatuses: StatusOption[] = [
  { id: 1, label: 'RETURN/REPLACE' },
  { id: 2, label: 'RETURN/REFUND' },
  { id: 6, label: 'PENDING' },
  { id: 3, label: 'IN TRANSIT' },
  { id: 31, label: 'REJECTED' },
];
/** CHANGED (new): the order's tracking: the returned product (7, variant 3) and another product of the order. */
const shipment: ShipmentTracking = {
  orderId: 'ORDF0F7C67DDF4611F197100AFFFC1C7849',
  placedOn: '2026-11-10T06:00:00.000Z',
  orderStatus: 'DELIVERED',
  shippingStatus: 'DELIVERED',
  shipmentNumber: 'SHP0005',
  carrier: { name: 'BlueDart', code: 'BLU', color: '#e63946', trackingNo: 'TRK0005' },
  scheduleStatus: '',
  onSchedule: true,
  estimatedDelivery: null,
  steps: [],
  currentStep: 0,
  items: [
    {
      orderId: 30, productId: 16, variantId: 25, sellerId: 49, shippingId: 5, deliveryAddressId: 10,
      name: 'Lenovo IdeaPad Slim 57', sku: 'SKU0016', quantity: 1, price: 6000, icon: '', tone: 'accent',
    },
    {
      orderId: 7, productId: 7, variantId: 3, sellerId: 24, shippingId: 5, deliveryAddressId: 1,
      name: 'Lenovo ThinkPad E14', sku: 'SKU0007', quantity: 2, price: 45000, icon: '', tone: 'neutral',
    },
  ],
  address: { name: 'Pooja Sree', lines: ['13/5a, 2nd Street', 'Chennai, Tamil Nadu, India, 600040'], phone: '9876543210' },
};
const returnReasons: ReturnReasonOption[] = [
  { REASON_ID: 19, REASON: 'Product is unsuitable for my needs' },
  { REASON_ID: 20, REASON: 'Other' },
];

function makeReturnRequest(overrides: Partial<ReturnRequestRow> = {}): ReturnRequestRow {
  return {
    returnId: 2,
    orderId: 7,
    orderNumber: 'ORDF0F7C67DDF4611F197100AFFFC1C7849',
    productId: 7,
    productName: 'Lenovo ThinkPad E14',
    quantity: 2,
    reason: 'Product Damaged',
    description: 'Received damaged product',
    images: ['image-1.jpg', 'image-2.jpg', 'image-3.jpg', 'image-4.jpg'],
    pickupAddressId: 1,
    address: '13/5a, 2nd Street, Chennai',
    sellerId: null,
    customerId: 1,
    customerName: 'Pooja Sree',
    customerMobile: '43559488848',
    variantId: 3,
    status: 'PENDING',
    createdAt: '2026-11-16T02:45:11.000Z',
    // CHANGED (new)
    statusId: null,
    reasonId: null,
    returnOptionId: 28,
    returnOptionName: null,
    sellerName: null,
    ...overrides,
  };
}

describe('ReturnRequest', () => {
  let fixture: ComponentFixture<ReturnRequest>;
  let root: HTMLElement;
  let orderService: {
    getOrderStatuses: ReturnType<typeof vi.fn>;
    getReturnReasons: ReturnType<typeof vi.fn>;
    getReturnRequests: ReturnType<typeof vi.fn>;
    getSellerReturnRequests: ReturnType<typeof vi.fn>;
    // CHANGED (new)
    getShippingStatuses: ReturnType<typeof vi.fn>;
    getReturnStatuses: ReturnType<typeof vi.fn>;
    getShipmentTracking: ReturnType<typeof vi.fn>;
    reviewReturnRequest: ReturnType<typeof vi.fn>;
    returnReviewErrorMessage: ReturnType<typeof vi.fn>;
  };
  let toast: { showError: ReturnType<typeof vi.fn>; showSuccess: ReturnType<typeof vi.fn> };
  // CHANGED (new): the screen picks the Admin or Seller API from the logged-in role (Admin by default).
  let userType: string;
  let sellerOnboarding: { getCurrentSellerId: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    const defaultPage: ReturnRequestsPage = { requests: [makeReturnRequest()], totalRecords: 25 };
    orderService = {
      getOrderStatuses: vi.fn(() => of(orderStatuses)),
      getReturnReasons: vi.fn(() => of(returnReasons)),
      getReturnRequests: vi.fn(() => of(defaultPage)),
      getSellerReturnRequests: vi.fn(() => of(defaultPage)),
      getShippingStatuses: vi.fn(() => of(shippingStatuses)),
      getReturnStatuses: vi.fn(() => of(returnStatuses)),
      getShipmentTracking: vi.fn(() => of(shipment)),
      reviewReturnRequest: vi.fn(() => of('Return request updated successfully.')),
      returnReviewErrorMessage: vi.fn((error: unknown) => (error instanceof Error ? error.message : 'Failed.')),
    };
    toast = { showError: vi.fn(), showSuccess: vi.fn() };
    userType = 'ADMIN';
    sellerOnboarding = { getCurrentSellerId: vi.fn(() => of(24)) };
    await TestBed.configureTestingModule({
      imports: [ReturnRequest],
      providers: [
        { provide: OrderService, useValue: orderService },
        { provide: ToastService, useValue: toast },
        { provide: AuthService, useValue: { user: () => ({ userType }) } },
        { provide: SellerOnboardingService, useValue: sellerOnboarding },
      ],
    }).compileComponents();
  });

  async function renderScreen(): Promise<void> {
    fixture = TestBed.createComponent(ReturnRequest);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    root = fixture.nativeElement as HTMLElement;
  }

  async function settle(): Promise<void> {
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }

  // CHANGED (new): the details / status update dialog.
  const text = (element: Element | null | undefined): string => (element?.textContent ?? '').replace(/\s+/g, ' ').trim();
  const dialog = (): HTMLElement | null => root.querySelector('.return-dialog');
  /** The dialog's current return status and return type. */
  const statusBadges = (): string[] =>
    Array.from(dialog()?.querySelectorAll('.return-dialog__statuses app-badge') ?? [], (badge) => text(badge));
  const buttonIn = (container: Element | null, label: string): HTMLButtonElement =>
    Array.from(container?.querySelectorAll<HTMLButtonElement>('button') ?? []).find((button) => text(button) === label)!;
  /** label → value of a details section ("Order & product", …). */
  const section = (title: string): Record<string, string> => {
    const heading = Array.from(dialog()?.querySelectorAll('h3') ?? []).find((h3) => text(h3) === title);
    const list = heading?.nextElementSibling;
    return Object.fromEntries(
      Array.from(list?.querySelectorAll('dl > div') ?? [], (item) => [text(item.querySelector('dt')), text(item.querySelector('dd'))]),
    );
  };

  async function openDetails(index = 0): Promise<void> {
    root.querySelectorAll<HTMLButtonElement>('button[aria-label^="View return"]')[index].click();
    await settle();
  }

  /** The row's Review action: the details at Approve / Reject. */
  async function openReview(index = 0): Promise<void> {
    root.querySelectorAll<HTMLButtonElement>('button[aria-label^="Review return"]')[index].click();
    await settle();
  }

  /** The Return status dropdown of the review: its option labels, or picks one. */
  async function reviewStatusOptions(): Promise<string[]> {
    const trigger = root.querySelector<HTMLButtonElement>('#review-return-status')!;
    trigger.click();
    await settle();
    const labels = Array.from(dialog()?.querySelectorAll('[role="option"]') ?? [], (option) => text(option));
    trigger.click();
    await settle();
    return labels;
  }

  async function pickReviewStatus(label: string): Promise<void> {
    root.querySelector<HTMLButtonElement>('#review-return-status')!.click();
    await settle();
    Array.from(dialog()!.querySelectorAll<HTMLButtonElement>('[role="option"]')).find((option) => text(option) === label)!.click();
    await settle();
  }

  /** Picks a return status, then Update Status, then (unless `confirm` is false) its confirmation. */
  async function updateStatus(label: string, confirm = true): Promise<void> {
    await pickReviewStatus(label);
    buttonIn(dialog(), 'Update Status').click();
    await settle();
    if (!confirm) return;
    buttonIn(dialog(), 'Confirm Update').click();
    await settle();
  }

  it('loads API records with all statuses and the required initial filters', async () => {
    await renderScreen();

    expect(orderService.getOrderStatuses).toHaveBeenCalledOnce();
    expect(orderService.getOrderStatuses).toHaveBeenCalledWith(10, 0);
    expect(orderService.getReturnReasons).toHaveBeenCalledOnce();
    expect(orderService.getReturnRequests).toHaveBeenCalledOnce();
    expect(orderService.getReturnRequests).toHaveBeenCalledWith({
      DAYS: 30,
      RETURN_STATUS: -1,
      RETURN_REASON: -1,
      LIMIT: 10,
      OFFSET: 0,
    });
    expect(orderService.getSellerReturnRequests).not.toHaveBeenCalled();
    expect(sellerOnboarding.getCurrentSellerId).not.toHaveBeenCalled();
    expect(root.querySelector('h1')?.textContent).toContain('Return Request');
    expect(root.querySelectorAll('app-stat-card').length).toBe(5);
    expect(root.querySelectorAll('tbody tr').length).toBe(1);
    expect(root.querySelector('tbody')?.textContent).toContain(
      'ORDF0F7C67DDF4611F197100AFFFC1C7849',
    );
    // CHANGED: the Return ID, Return Type and Requested On columns; the photos are in the details dialog. No row
    // selection column (and no checkboxes).
    expect(Array.from(root.querySelectorAll('thead th'), (th) => th.textContent?.trim())).toEqual([
      'Return ID', 'Order No', 'Product', 'Seller', 'Quantity', 'Return Type', 'Return Reason', 'Pickup Address',
      'Return Status', 'Requested On', 'Actions',
    ]);
    expect(root.querySelector('.admin-list-table app-checkbox, .admin-list-table input[type="checkbox"]')).toBeNull();
    expect(root.querySelector('.return-id')?.textContent?.trim()).toBe('#2');
    // The product's variant under its name; the seller (no SELLER_ID here).
    expect(root.querySelector('tbody')?.textContent).toContain('Variant #3');
    expect(root.querySelector('tbody td:nth-child(4)')?.textContent?.trim()).toBe('—');
    // View and Review.
    expect(root.querySelector('button[aria-label="View return #2"]')).not.toBeNull();
    expect(root.querySelector('button[aria-label="Review return #2"]')).not.toBeNull();
    // CHANGED: no row menu (Approve / Reject are in the details).
    expect(root.querySelector('tbody .more-actions')).toBeNull();
    expect(root.querySelector('tbody')?.textContent).toContain('Lenovo ThinkPad E14');
    expect(root.querySelector('tbody')?.textContent).toContain('Received damaged product');
    expect(root.querySelector('tbody')?.textContent).toContain('Pooja Sree');
    expect(root.querySelector('tbody')?.textContent).toContain('43559488848');
    expect(root.querySelector('tbody')?.textContent).toContain('13/5a, 2nd Street, Chennai');
    expect(root.querySelector('tbody')?.textContent).toContain('Pending');
    // RETURN_OPTION 28 named from the return types.
    expect(orderService.getShippingStatuses).toHaveBeenCalledOnce();
    expect(root.querySelector('tbody app-badge')?.textContent?.trim()).toBe('Return/Refund');
    // CHANGED (new): the Review's options: return_status, RETURN_STATUS_ID=-1&LIMIT=10&OFFSET=0.
    expect(orderService.getReturnStatuses).toHaveBeenCalledOnce();
    expect(orderService.getReturnStatuses).toHaveBeenCalledWith(10, 0);
    expect(root.querySelector('.return-images__item')).toBeNull();
    // Created date uses the project's 'dd MMM y' format (day depends on the test machine's zone).
    expect(root.querySelector('.return-date')?.textContent).toMatch(/^\d{2} Nov 2026$/);
  });

  it('selects All Status, All reasons and 30 days by default', async () => {
    await renderScreen();

    expect(root.querySelector<HTMLSelectElement>('#admin-return-status')!.value).toBe('-1');
    expect(root.querySelector<HTMLSelectElement>('#admin-return-reason')!.value).toBe('-1');
    expect(root.querySelector<HTMLSelectElement>('#return-date-range')!.value).toBe('30');
  });

  // CHANGED: the details' Return status (a return status): its RETURN_STATUS_ID and ACTION.
  it('resolves numeric status IDs through All Status and sends the picked return status\'s ID', async () => {
    orderService.getOrderStatuses.mockReturnValue(of([{ id: 6, label: 'PENDING' }, { id: 7, label: 'APPROVED' }]));
    orderService.getReturnRequests.mockReturnValue(
      of({ requests: [makeReturnRequest({ status: '6' })], totalRecords: 1 }),
    );
    await renderScreen();

    const row = root.querySelector('tbody tr') as HTMLElement;
    expect(row.textContent).toContain('Pending');
    await openReview();
    await updateStatus('In Transit');

    expect(orderService.reviewReturnRequest).toHaveBeenCalledWith({ RETURN_ID: 2, RETURN_STATUS: 3, ACTION: 'APPROVED' });
  });

  it('renders a row whose optional fields are all null without errors', async () => {
    orderService.getReturnRequests.mockReturnValue(
      of({
        requests: [
          makeReturnRequest({
            returnId: 9,
            orderId: null,
            orderNumber: null,
            productId: null,
            productName: null,
            quantity: null,
            reason: null,
            description: null,
            images: [],
            pickupAddressId: null,
            address: null,
            customerId: null,
            customerName: null,
            customerMobile: null,
            variantId: null,
            status: null,
            createdAt: null,
          }),
        ],
        totalRecords: 1,
      } satisfies ReturnRequestsPage),
    );
    await renderScreen();

    const row = root.querySelector('tbody tr') as HTMLElement;
    expect(row.querySelector('.return-id')?.textContent?.trim()).toBe('#9');
    expect(row.querySelector('.return-date')?.textContent?.trim()).toBe('—');
    expect(row.textContent).toContain('—');
  });

  it('shows API-provided status and reason labels and sends their IDs when changed', async () => {
    await renderScreen();

    const status = root.querySelector<HTMLSelectElement>('#admin-return-status')!;
    const reason = root.querySelector<HTMLSelectElement>('#admin-return-reason')!;
    expect(Array.from(status.options).map((option) => option.textContent?.trim())).toEqual([
      'All Status',
      'PENDING',
      'APPROVED',
      'REJECTED',
    ]);
    expect(Array.from(reason.options).map((option) => option.textContent?.trim())).toEqual([
      'All Return Reasons',
      'Product is unsuitable for my needs',
      'Other',
    ]);
    expect(reason.options[1].value).toBe('19');

    status.value = '25';
    status.dispatchEvent(new Event('change'));
    await settle();
    reason.value = '19';
    reason.dispatchEvent(new Event('change'));
    await settle();

    expect(orderService.getReturnRequests).toHaveBeenLastCalledWith({
      DAYS: 30,
      RETURN_STATUS: 25,
      RETURN_REASON: 19,
      LIMIT: 10,
      OFFSET: 0,
    });
  });

  it('refreshes the existing table from each filtered and paginated API response', async () => {
    orderService.getReturnRequests
      .mockReturnValueOnce(
        of({
          requests: [makeReturnRequest({ orderNumber: 'ORD-FIRST-PAGE' })],
          totalRecords: 25,
        } satisfies ReturnRequestsPage),
      )
      .mockReturnValue(
        of({
          requests: [makeReturnRequest({ returnId: 12, orderNumber: 'ORD-UPDATED-PAGE' })],
          totalRecords: 15,
        } satisfies ReturnRequestsPage),
      );
    await renderScreen();

    expect(root.querySelector('tbody')?.textContent).toContain('ORD-FIRST-PAGE');
    const status = root.querySelector<HTMLSelectElement>('#admin-return-status')!;
    status.value = '25';
    status.dispatchEvent(new Event('change'));
    await settle();
    expect(root.querySelector('tbody')?.textContent).toContain('ORD-UPDATED-PAGE');
    expect(root.querySelector('tbody')?.textContent).not.toContain('ORD-FIRST-PAGE');

    const nextPage = root.querySelector<HTMLButtonElement>(
      'nav[aria-label="Return request pages"] button[aria-label="Next page"]',
    )!;
    nextPage.click();
    await settle();
    expect(orderService.getReturnRequests).toHaveBeenLastCalledWith({
      DAYS: 30,
      RETURN_STATUS: 25,
      RETURN_REASON: -1,
      LIMIT: 10,
      OFFSET: 10,
    });
    expect(root.querySelector('tbody')?.textContent).toContain('ORD-UPDATED-PAGE');
  });

  it('resets the offset when days or lookup filters change and paginates from total_records', async () => {
    await renderScreen();

    const nextPage = root.querySelector<HTMLButtonElement>(
      'nav[aria-label="Return request pages"] button[aria-label="Next page"]',
    )!;
    nextPage.click();
    await settle();
    expect(orderService.getReturnRequests).toHaveBeenLastCalledWith({
      DAYS: 30,
      RETURN_STATUS: -1,
      RETURN_REASON: -1,
      LIMIT: 10,
      OFFSET: 10,
    });

    const dateRange = root.querySelector<HTMLSelectElement>('#return-date-range')!;
    dateRange.value = '90';
    dateRange.dispatchEvent(new Event('change'));
    await settle();
    expect(orderService.getReturnRequests).toHaveBeenLastCalledWith({
      DAYS: 90,
      RETURN_STATUS: -1,
      RETURN_REASON: -1,
      LIMIT: 10,
      OFFSET: 0,
    });
  });

  it('shows an empty state for an empty API page', async () => {
    orderService.getReturnRequests.mockReturnValue(
      of({ requests: [], totalRecords: 0 } satisfies ReturnRequestsPage),
    );
    await renderScreen();

    expect(root.querySelector('tbody')?.textContent).toContain('No return requests match these filters.');
    expect(root.querySelector('.pagination__summary')?.textContent).toContain('0 requests');
  });

  it('shows an API error and retries the request', async () => {
    orderService.getReturnRequests
      .mockReturnValueOnce(throwError(() => new Error('Return service unavailable.')))
      .mockReturnValue(of({ requests: [], totalRecords: 0 } satisfies ReturnRequestsPage));
    await renderScreen();

    expect(root.querySelector('[role="alert"]')?.textContent).toContain(
      'Return service unavailable.',
    );
    expect(toast.showError).toHaveBeenCalledWith('Return service unavailable.');
    (root.querySelector('.alert button') as HTMLButtonElement).click();
    await settle();

    expect(orderService.getReturnRequests).toHaveBeenCalledTimes(2);
    expect(root.querySelector('[role="alert"]')).toBeNull();
    expect(root.querySelector('tbody')?.textContent).toContain('No return requests match these filters.');
  });

  it('shows an empty reason state and retries a failed reason lookup', async () => {
    orderService.getReturnReasons
      .mockReturnValueOnce(throwError(() => new Error('Reasons unavailable.')))
      .mockReturnValue(of(returnReasons));
    await renderScreen();

    expect(root.querySelector('[role="alert"]')?.textContent).toContain('Reasons unavailable.');
    expect(toast.showError).toHaveBeenCalledWith('Reasons unavailable.');
    (root.querySelector('.admin-list-filter-error button') as HTMLButtonElement).click();
    await settle();

    expect(orderService.getReturnReasons).toHaveBeenCalledTimes(2);
    expect(Array.from(root.querySelectorAll('#admin-return-reason option')).map((option) => option.textContent?.trim()))
      .toContain('Other');
  });

  it('loads all requests when the All Status API has no PENDING record', async () => {
    orderService.getOrderStatuses.mockReturnValue(of([{ id: 25, label: 'APPROVED' }]));
    await renderScreen();

    expect(orderService.getReturnRequests).toHaveBeenCalledWith({
      DAYS: 30,
      RETURN_STATUS: -1,
      RETURN_REASON: -1,
      LIMIT: 10,
      OFFSET: 0,
    });
    expect(root.querySelector('tbody')?.textContent).toContain('ORDF0F7C67DDF4611F197100AFFFC1C7849');
  });

  it('keeps the Return Requests table available when the status lookup fails', async () => {
    orderService.getOrderStatuses.mockReturnValue(
      throwError(() => new Error('Return statuses unavailable.')),
    );
    await renderScreen();

    expect(orderService.getReturnRequests).toHaveBeenCalledWith({
      DAYS: 30,
      RETURN_STATUS: -1,
      RETURN_REASON: -1,
      LIMIT: 10,
      OFFSET: 0,
    });
    expect(root.querySelector('tbody')?.textContent).toContain('ORDF0F7C67DDF4611F197100AFFFC1C7849');
    expect(root.querySelector('[role="alert"]')?.textContent).toContain(
      'Return statuses unavailable.',
    );
  });

  // ---- CHANGED (new): details, and their Approve / Reject ----

  it('shows a request\'s details with the returned product\'s SKU, price, seller and shipment from its tracking', async () => {
    await renderScreen();
    await openDetails();

    expect(orderService.getShipmentTracking).toHaveBeenCalledWith('ORDF0F7C67DDF4611F197100AFFFC1C7849');
    expect(dialog()?.getAttribute('role')).toBe('dialog');
    expect(text(dialog()?.querySelector('h2'))).toBe('Return #2');
    expect(statusBadges()).toEqual(['Pending', 'Return/Refund']);
    expect(section('Return details')).toMatchObject({
      'Return ID': '#2', 'Return Type': 'Return/Refund', 'Return Reason': 'Product Damaged',
      'Additional Details': 'Received damaged product',
    });
    // The tracking row of the returned product (7, variant 3), not the order's other product.
    expect(section('Order & product')).toEqual({
      'Order Number': 'ORDF0F7C67DDF4611F197100AFFFC1C7849', Product: 'Lenovo ThinkPad E14', SKU: 'SKU0007',
      Variant: '#3', Quantity: '2', 'Unit Price': '₹45,000.00', Seller: 'Seller #24',
    });
    expect(section('Pickup')).toEqual({
      'Pickup Address': '13/5a, 2nd Street, Chennai', Customer: 'Pooja Sree', Mobile: '43559488848',
    });
    expect(section('Shipment')).toEqual({
      'Order Status': 'Delivered', 'Shipping Status': 'Delivered', Carrier: 'BlueDart', 'Tracking Number': 'TRK0005',
      'Shipment Number': 'SHP0005',
    });
    // Every photo of the request.
    expect(dialog()?.querySelectorAll('.return-gallery__item img').length).toBe(4);

    buttonIn(dialog(), 'Close').click();
    await settle();
    expect(dialog()).toBeNull();
  });

  it('keeps the details without the shipment when the order\'s tracking cannot be read, with Try again', async () => {
    orderService.getShipmentTracking
      .mockReturnValueOnce(throwError(() => new Error('Tracking unavailable')))
      .mockReturnValue(of(shipment));
    await renderScreen();
    await openDetails();

    expect(text(dialog())).toContain('Shipment details are not available for this order.');
    expect(section('Order & product')).toMatchObject({ SKU: '—', 'Unit Price': '—', Product: 'Lenovo ThinkPad E14' });
    buttonIn(dialog(), 'Try again').click();
    await settle();
    expect(section('Order & product')).toMatchObject({ SKU: 'SKU0007' });
  });

  // CHANGED: a Return status dropdown of the return statuses (return_status) and Update Status; no Approve / Reject
  // buttons.
  it('changes a request to the return status picked after a confirmation, then refreshes the listing and details', async () => {
    orderService.getReturnRequests
      .mockReturnValueOnce(of({ requests: [makeReturnRequest()], totalRecords: 25 }))
      .mockReturnValue(of({ requests: [makeReturnRequest({ status: 'IN TRANSIT', statusId: 3 })], totalRecords: 25 }));
    await renderScreen();
    await openReview();

    expect(dialog()).not.toBeNull();
    expect(text(dialog()?.querySelector('#return-review-title'))).toBe('Review return');
    expect(buttonIn(dialog(), 'Approve')).toBeUndefined();
    expect(buttonIn(dialog(), 'Reject')).toBeUndefined();
    // Nothing chosen yet: Update Status waits for a status. Every return status but the request's own (Pending).
    expect(text(root.querySelector('#review-return-status'))).toBe('Select the return status');
    expect(buttonIn(dialog(), 'Update Status').disabled).toBe(true);
    expect(await reviewStatusOptions()).toEqual(['Return/Replace', 'Return/Refund', 'In Transit', 'Rejected']);
    await updateStatus('In Transit', false);

    // Confirmation first: nothing sent yet.
    const confirm = dialog()?.querySelector('.return-decision-confirm');
    expect(confirm?.getAttribute('role')).toBe('alertdialog');
    expect(text(confirm?.querySelector('h4'))).toBe('Confirm the status change?');
    expect(text(confirm?.querySelector('p'))).toBe('Change return #2 for Lenovo ThinkPad E14 to In Transit?');
    // The status cannot change while the confirmation is open.
    expect(root.querySelector<HTMLButtonElement>('#review-return-status')?.disabled).toBe(true);
    expect(buttonIn(dialog(), 'Update Status').disabled).toBe(true);
    expect(orderService.reviewReturnRequest).not.toHaveBeenCalled();
    buttonIn(confirm!, 'Cancel').click();
    await settle();
    expect(dialog()?.querySelector('.return-decision-confirm')).toBeNull();

    buttonIn(dialog(), 'Update Status').click();
    await settle();
    buttonIn(dialog(), 'Confirm Update').click();
    await settle();

    expect(orderService.reviewReturnRequest).toHaveBeenCalledOnce();
    // In Transit's RETURN_STATUS_ID (3); any status but Rejected is APPROVED.
    expect(orderService.reviewReturnRequest).toHaveBeenCalledWith({ RETURN_ID: 2, RETURN_STATUS: 3, ACTION: 'APPROVED' });
    expect(toast.showSuccess).toHaveBeenCalledWith('Return request updated successfully.');
    // The listing and the order's tracking are read again; the table stays on screen meanwhile.
    expect(orderService.getReturnRequests).toHaveBeenCalledTimes(2);
    expect(orderService.getShipmentTracking).toHaveBeenCalledTimes(2);
    expect(root.querySelector('tbody tr')?.textContent).toContain('In Transit');
    // The dialog stays open on the new status; it can be changed again (to any other status).
    expect(statusBadges()[0]).toBe('In Transit');
    expect(text(dialog()?.querySelector('#return-review'))).toContain('It is In Transit now.');
    expect(await reviewStatusOptions()).toEqual(['Return/Replace', 'Return/Refund', 'Pending', 'Rejected']);
    expect(text(root.querySelector('#review-return-status'))).toBe('Select the return status');
  });

  it('shows the status picked at once, before the listing is read again', async () => {
    let finishUpdate!: (message: string) => void;
    orderService.reviewReturnRequest.mockReturnValueOnce(
      new Observable<string>((subscriber) => {
        finishUpdate = (message) => {
          subscriber.next(message);
          subscriber.complete();
        };
      }),
    );
    // The listing read after the update fails: the table keeps the status shown.
    orderService.getReturnRequests
      .mockReturnValueOnce(of({ requests: [makeReturnRequest()], totalRecords: 25 }))
      .mockReturnValue(throwError(() => new Error('Listing unavailable')));
    await renderScreen();
    await openReview();
    await updateStatus('Rejected');

    // A Rejected status is sent with ACTION REJECTED.
    expect(orderService.reviewReturnRequest).toHaveBeenCalledWith({ RETURN_ID: 2, RETURN_STATUS: 31, ACTION: 'REJECTED' });
    finishUpdate('Return request rejected');
    await settle();
    expect(statusBadges()[0]).toBe('Rejected');
    expect(root.querySelector('tbody tr')?.textContent).toContain('Rejected');
    expect(toast.showError).toHaveBeenCalledWith('Listing unavailable');
  });

  it('rejects after a confirmation, and keeps the request Pending with the reason when it fails', async () => {
    orderService.reviewReturnRequest.mockReturnValueOnce(throwError(() => new Error('Return request is not pending')));
    await renderScreen();
    await openReview();
    await updateStatus('Rejected', false);
    expect(text(dialog()?.querySelector('.return-decision-confirm p'))).toBe('Change return #2 for Lenovo ThinkPad E14 to Rejected?');
    buttonIn(dialog(), 'Confirm Update').click();
    await settle();

    expect(orderService.reviewReturnRequest).toHaveBeenCalledWith({ RETURN_ID: 2, RETURN_STATUS: 31, ACTION: 'REJECTED' });
    expect(orderService.returnReviewErrorMessage).toHaveBeenCalledWith(expect.any(Error), 'REJECTED');
    expect(text(dialog()?.querySelector('.return-dialog__alert'))).toBe('Return request is not pending');
    expect(toast.showError).toHaveBeenCalledWith('Return request is not pending');
    expect(root.querySelector('tbody tr')?.textContent).toContain('Pending');
    expect(orderService.getReturnRequests).toHaveBeenCalledOnce();
    // The choice is kept and can be sent again.
    expect(text(root.querySelector('#review-return-status'))).toBe('Rejected');
    expect(buttonIn(dialog(), 'Update Status').disabled).toBe(false);
  });

  it('shows the update in progress and sends it once', async () => {
    let finishUpdate!: (message: string) => void;
    orderService.reviewReturnRequest.mockReturnValueOnce(
      new Observable<string>((subscriber) => {
        finishUpdate = (message) => {
          subscriber.next(message);
          subscriber.complete();
        };
      }),
    );
    await renderScreen();
    await openReview();
    await updateStatus('In Transit');

    const confirm = buttonIn(dialog(), 'Processing…');
    expect(confirm.getAttribute('aria-busy')).toBe('true');
    expect(confirm.disabled).toBe(true);
    expect(buttonIn(dialog(), 'Cancel').disabled).toBe(true);
    expect(buttonIn(dialog(), 'Close').disabled).toBe(true);
    expect(buttonIn(dialog(), 'Update Status').disabled).toBe(true);
    expect(dialog()?.querySelector<HTMLButtonElement>('.return-dialog__close')?.disabled).toBe(true);
    confirm.click();
    await settle();
    expect(orderService.reviewReturnRequest).toHaveBeenCalledOnce();

    finishUpdate('Approved.');
    await settle();
    expect(orderService.getReturnRequests).toHaveBeenCalledTimes(2);
  });

  // CHANGED: the return statuses (it was the shipping statuses); RETURN_STATUS is the RETURN_STATUS_ID picked.
  it('cannot update while the return statuses are unavailable, and offers Retry', async () => {
    orderService.getReturnStatuses
      .mockReturnValueOnce(throwError(() => new Error('Return statuses unavailable.')))
      .mockReturnValue(of(returnStatuses));
    await renderScreen();
    await openReview();

    expect(root.querySelector<HTMLButtonElement>('#review-return-status')?.disabled).toBe(true);
    expect(buttonIn(dialog(), 'Update Status').disabled).toBe(true);
    const review = dialog()?.querySelector('#return-review') ?? null;
    expect(text(review)).toContain('Return statuses could not be loaded, so the return cannot be updated right now.');

    buttonIn(review, 'Retry').click();
    await settle();
    expect(orderService.getReturnStatuses).toHaveBeenCalledTimes(2);
    expect(orderService.getShippingStatuses).toHaveBeenCalledOnce();
    expect(await reviewStatusOptions()).toEqual(['Return/Replace', 'Return/Refund', 'In Transit', 'Rejected']);
    await updateStatus('Return/Refund');
    expect(orderService.reviewReturnRequest).toHaveBeenCalledWith({ RETURN_ID: 2, RETURN_STATUS: 2, ACTION: 'APPROVED' });
  });

  it('says so when there is no other return status', async () => {
    orderService.getReturnStatuses.mockReturnValue(of([{ id: 6, label: 'PENDING' }]));
    await renderScreen();
    await openReview();

    expect(text(dialog()?.querySelector('#return-review'))).toContain('There is no other return status to change this return to.');
    expect(root.querySelector<HTMLButtonElement>('#review-return-status')?.disabled).toBe(true);
    expect(buttonIn(dialog(), 'Update Status').disabled).toBe(true);
  });

  // CHANGED: every status is reviewed (it was Pending only); the status the request has is not offered.
  it('updates a request in any status, offering every return status but its own', async () => {
    orderService.getReturnRequests.mockReturnValue(of({
      requests: [
        makeReturnRequest({ returnId: 5, status: 'REJECTED', statusId: 31 }),
        makeReturnRequest({ returnId: 6, status: 'IN TRANSIT', statusId: 3 }),
      ],
      totalRecords: 2,
    }));
    await renderScreen();

    await openReview(0);
    expect(text(dialog()?.querySelector('#return-review'))).toContain('It is Rejected now.');
    expect(await reviewStatusOptions()).toEqual(['Return/Replace', 'Return/Refund', 'Pending', 'In Transit']);
    await updateStatus('Return/Replace');
    expect(orderService.reviewReturnRequest).toHaveBeenCalledWith({ RETURN_ID: 5, RETURN_STATUS: 1, ACTION: 'APPROVED' });
    buttonIn(dialog(), 'Close').click();
    await settle();

    await openReview(1);
    expect(await reviewStatusOptions()).toEqual(['Return/Replace', 'Return/Refund', 'Pending', 'Rejected']);
    await updateStatus('Rejected');
    expect(orderService.reviewReturnRequest).toHaveBeenLastCalledWith({ RETURN_ID: 6, RETURN_STATUS: 31, ACTION: 'REJECTED' });
  });

  it('sorts the page\'s requests by a column, ascending then descending', async () => {
    orderService.getReturnRequests.mockReturnValue(of({
      requests: [
        makeReturnRequest({ returnId: 5, orderNumber: 'ORD0005', createdAt: '2026-11-18T02:00:00.000Z' }),
        makeReturnRequest({ returnId: 2, orderNumber: 'ORD0010', createdAt: null }),
        makeReturnRequest({ returnId: 9, orderNumber: 'ORD0001', createdAt: '2026-11-12T02:00:00.000Z' }),
      ],
      totalRecords: 3,
    }));
    await renderScreen();
    const ids = (): string[] => Array.from(root.querySelectorAll('.return-id'), (cell) => text(cell));
    const sortBy = async (label: string): Promise<void> => {
      root.querySelector<HTMLButtonElement>(`button[aria-label^="Sort by ${label}"]`)!.click();
      await settle();
    };

    expect(ids()).toEqual(['#5', '#2', '#9']);
    await sortBy('Return ID');
    expect(ids()).toEqual(['#2', '#5', '#9']);
    expect(root.querySelector('button[aria-label^="Sort by Return ID"]')?.getAttribute('aria-label')).toBe('Sort by Return ID, sorted ascending');
    await sortBy('Return ID');
    expect(ids()).toEqual(['#9', '#5', '#2']);
    // A request without a date goes last.
    await sortBy('Requested On');
    expect(ids()).toEqual(['#9', '#5', '#2']);
    await sortBy('Order No');
    expect(ids()).toEqual(['#9', '#5', '#2']);
  });

  // CHANGED (new): Seller login uses the SELLER_ID return request API with the same table and pagination.
  describe('for a Seller login', () => {
    beforeEach(() => {
      userType = 'SELLER';
    });

    it('loads the logged-in seller\'s requests by SELLER_ID and paging only', async () => {
      await renderScreen();

      expect(sellerOnboarding.getCurrentSellerId).toHaveBeenCalled();
      expect(orderService.getSellerReturnRequests).toHaveBeenCalledOnce();
      expect(orderService.getSellerReturnRequests).toHaveBeenCalledWith({
        SELLER_ID: 24,
        LIMIT: 10,
        OFFSET: 0,
      });
      expect(orderService.getReturnRequests).not.toHaveBeenCalled();
      expect(root.querySelector('tbody')?.textContent).toContain('ORDF0F7C67DDF4611F197100AFFFC1C7849');
      expect(root.querySelector('tbody')?.textContent).toContain('Pending');
    });

    it('uses whichever seller ID the logged-in seller resolves to', async () => {
      sellerOnboarding.getCurrentSellerId.mockReturnValue(of(57));
      await renderScreen();

      expect(orderService.getSellerReturnRequests).toHaveBeenCalledWith({
        SELLER_ID: 57,
        LIMIT: 10,
        OFFSET: 0,
      });
    });

    it('hides the Admin-only day, status and reason filters and skips the reason lookup', async () => {
      await renderScreen();

      expect(root.querySelector('#return-date-range')).toBeNull();
      expect(root.querySelector('#admin-return-status')).toBeNull();
      expect(root.querySelector('#admin-return-reason')).toBeNull();
      expect(orderService.getReturnReasons).not.toHaveBeenCalled();
      expect(root.textContent).not.toContain('Loading return reasons');
      expect(root.querySelector('#admin-return-search')).toBeTruthy();
      expect(root.querySelector('app-export-button')).toBeTruthy();
    });

    it('paginates from total_records with the same SELLER_ID', async () => {
      await renderScreen();

      const nextPage = root.querySelector<HTMLButtonElement>(
        'nav[aria-label="Return request pages"] button[aria-label="Next page"]',
      )!;
      nextPage.click();
      await settle();

      expect(orderService.getSellerReturnRequests).toHaveBeenLastCalledWith({
        SELLER_ID: 24,
        LIMIT: 10,
        OFFSET: 10,
      });
      expect(orderService.getReturnRequests).not.toHaveBeenCalled();
    });

    // CHANGED: the details' Return status (a return status), with its ID and ACTION.
    it('lets a seller update a Pending request from its details and refreshes the seller list', async () => {
      orderService.getOrderStatuses.mockReturnValue(of([{ id: 6, label: 'PENDING' }, { id: 7, label: 'APPROVED' }]));
      orderService.getSellerReturnRequests.mockReturnValue(
        of({ requests: [makeReturnRequest({ status: '6', sellerId: 24 })], totalRecords: 2 }),
      );
      await renderScreen();

      const row = root.querySelector('tbody tr') as HTMLElement;
      expect(row.textContent).toContain('Pending');
      expect(row.textContent).toContain('Seller #24');
      await openReview();
      await updateStatus('In Transit');

      expect(orderService.reviewReturnRequest).toHaveBeenCalledWith({ RETURN_ID: 2, RETURN_STATUS: 3, ACTION: 'APPROVED' });
      expect(orderService.getSellerReturnRequests).toHaveBeenCalledTimes(2);
      expect(orderService.getReturnRequests).not.toHaveBeenCalled();
    });

    it('shows an error with retry when the seller account cannot be resolved', async () => {
      sellerOnboarding.getCurrentSellerId
        .mockReturnValueOnce(throwError(() => new Error('The authenticated user does not have a valid seller account.')))
        .mockReturnValue(of(24));
      await renderScreen();

      expect(root.querySelector('.alert')?.textContent).toContain(
        'The authenticated user does not have a valid seller account.',
      );
      expect(orderService.getSellerReturnRequests).not.toHaveBeenCalled();
      (root.querySelector('.alert button') as HTMLButtonElement).click();
      await settle();

      expect(orderService.getSellerReturnRequests).toHaveBeenCalledWith({
        SELLER_ID: 24,
        LIMIT: 10,
        OFFSET: 0,
      });
      expect(root.querySelector('.alert')).toBeNull();
    });
  });

  // CHANGED: the widths without the selection column; together they take the whole table.
  it('keeps the table widths and centered status and quantity columns', async () => {
    await renderScreen();

    const headers = Array.from(root.querySelectorAll<HTMLTableCellElement>('thead th'));
    const pickupAddress = headers.find((header) => header.textContent?.trim() === 'Pickup Address');
    const returnStatus = headers.find((header) => header.textContent?.trim() === 'Return Status');
    const quantity = headers.find((header) => header.textContent?.trim() === 'Quantity');
    const statusCell = root.querySelector<HTMLTableCellElement>(
      `tbody tr td:nth-child(${headers.indexOf(returnStatus!) + 1})`,
    );
    const quantityCell = root.querySelector<HTMLTableCellElement>(
      `tbody tr td:nth-child(${headers.indexOf(quantity!) + 1})`,
    );

    expect(root.querySelector('.table-scroll')).toBeTruthy();
    expect(pickupAddress?.style.getPropertyValue('--column-width')).toBe('13%');
    expect(returnStatus?.style.getPropertyValue('--column-width')).toBe('9%');
    const totalWidth = headers.reduce((sum, header) => sum + parseFloat(header.style.getPropertyValue('--column-width')), 0);
    expect(totalWidth).toBe(100);
    expect(returnStatus?.style.textAlign).toBe('center');
    expect(statusCell?.style.textAlign).toBe('center');
    expect(quantity?.style.textAlign).toBe('center');
    expect(quantityCell?.style.textAlign).toBe('center');
  });
});