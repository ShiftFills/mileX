import { CurrencyPipe, DatePipe, DOCUMENT } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed, toObservable, toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { EMPTY, catchError, defer, finalize, map, switchMap, tap } from 'rxjs';
import { APP_ROUTES } from '@core/constants/app-routes';
import { ToastService } from '@core/services/toast.service';
import { Alert } from '@shared/components/alert/alert';
import { Button } from '@shared/components/button/button';
import { Card } from '@shared/components/card/card';
import { Dialog } from '@shared/components/dialog/dialog';
import { LoadingSpinner } from '@shared/components/loading-spinner/loading-spinner';
import { PageHeading } from '@shared/components/page-heading/page-heading';
import { SearchableSelect, SearchableSelectOption } from '@shared/components/searchable-select/searchable-select';
import { Stepper, StepperStep } from '@shared/components/stepper/stepper';
import { Textarea } from '@shared/components/textarea/textarea';
import { ReturnReasonOption, ReturnRequestResult, ShipmentItem, ShipmentTracking, StatusOption } from '@shared/models';
import { ShipmentMap } from '../../components/shipment-map/shipment-map';
import {
  OrderService,
  RETURN_DESCRIPTION_MAX_LENGTH,
  shipmentStage,
  shippingStatusLabel,
} from '../../services/order.service';

/** 24x24 icon paths for the timeline markers. */
const TRUCK_ICON = 'M2 6h11v10H2zM13 9.5h4.5l3 3.5V16H13M6.5 19a1.5 1.5 0 1 0 0-.01M17 19a1.5 1.5 0 1 0 0-.01';
const HOME_ICON = 'M4 11l8-7 8 7M6 10v9h12v-9M10 19v-5h4v5';
const COPIED_RESET_MS = 2000;
/** Order (or shipping) statuses that end an order before delivery, with the note shown instead of the steps. */
// CHANGED (new)
const CLOSED_STATUS_NOTES: Readonly<Record<string, string>> = {
  CANCELLED: 'This order was cancelled, so it will not be delivered.',
  FAILED: 'This order could not be completed, so it will not be delivered.',
  RETURNED: 'This shipment was returned.',
};

/** "In Transit" / "in-transit" -> "IN_TRANSIT". */
function statusKey(status: string | undefined): string {
  return (status ?? '').trim().toUpperCase().replace(/[\s-]+/g, '_');
}

/** A dropdown value as a positive ID, or null for '' (nothing chosen). */
// CHANGED (new): shared by the return type and reason dropdowns.
function selectedId(value: string): number | null {
  const id = Number(value);
  return value && Number.isSafeInteger(id) && id > 0 ? id : null;
}

/** A return request this page created, with what the customer chose (shown once the dialog closes). */
// CHANGED (new)
interface SubmittedReturn {
  orderNumber: string;
  result: ReturnRequestResult;
  /** The returned product, and the chosen return type ("Return/Refund") and reason, as the dialog showed them. */
  productName: string;
  typeLabel: string;
  reasonLabel: string;
}

/**
 * A product the dialog can return: one order line of the tracking response, with that row's own IDs. Rows with the
 * same ORDER_ID, PRODUCT_ID, PRODUCT_VARIANT_ID and SELLER_ID are the same line (the API can repeat a row), so they
 * are one choice; a row without a PRODUCT_ID is its own.
 */
// CHANGED (new)
interface ReturnCandidate {
  key: string;
  item: ShipmentItem;
  label: string;
}

function returnCandidates(items: readonly ShipmentItem[]): ReturnCandidate[] {
  const lines = new Map<string, ShipmentItem>();
  items.forEach((item, index) => {
    const key =
      item.productId === undefined
        ? `row-${index}`
        : [item.orderId ?? '', item.productId, item.variantId ?? '', item.sellerId ?? ''].join('|');
    if (!lines.has(key)) lines.set(key, item);
  });
  // "Name (SKU)"; lines that would read the same also show their variant (or their position).
  const base = (item: ShipmentItem): string => (item.sku ? `${item.name} (${item.sku})` : item.name);
  const counts = new Map<string, number>();
  for (const item of lines.values()) counts.set(base(item), (counts.get(base(item)) ?? 0) + 1);
  return [...lines].map(([key, item], index) => ({
    key,
    item,
    label:
      (counts.get(base(item)) ?? 0) > 1
        ? `${base(item)} · ${item.variantId ? `Variant ${item.variantId}` : `Item ${index + 1}`}`
        : base(item),
  }));
}

@Component({
  selector: 'app-shipment-tracking',
  // CHANGED: SearchableSelect (the dialog's dropdowns) instead of Select.
  imports: [Alert, Button, Card, CurrencyPipe, DatePipe, Dialog, LoadingSpinner, PageHeading, RouterLink, SearchableSelect, ShipmentMap, Stepper, Textarea],
  templateUrl: './shipment-tracking.html',
  styleUrl: './shipment-tracking.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
/**
 * Shipment Tracking (`/orders/:id/tracking`, :id is the ORDER_NUMBER): the tracking API's details of one order
 * (OrderService.getShipmentTracking). Nothing the API does not send is made up: the Live Route GPS Tracking card says
 * the live location is not available yet, and the payment card and the actions without an API are hidden.
 */
// CHANGED: reads the tracking API (it showed a demo shipment).
export class ShipmentTrackingPage {
  private readonly orders = inject(OrderService);
  private readonly document = inject(DOCUMENT);
  private readonly destroyRef = inject(DestroyRef);
  private readonly orderId = toSignal(inject(ActivatedRoute).paramMap.pipe(map((params) => params.get('id') ?? '')), {
    initialValue: '',
  });

  protected readonly routes = APP_ROUTES;
  /** The ORDER_NUMBER from the route, for the links back to its Order Details. */
  // CHANGED (new)
  protected readonly orderNumber = computed(() => this.orderId().trim());
  // CHANGED (new): the tracking request's state; a 'success' without a shipment is the "not shipped yet" state.
  protected readonly status = signal<'loading' | 'success' | 'error'>('loading');
  protected readonly error = signal('');
  protected readonly shipment = signal<ShipmentTracking | null>(null);
  private readonly retryCount = signal(0);

  protected readonly steps = computed<StepperStep[]>(() =>
    (this.shipment()?.steps ?? []).map((step) => ({ ...step, icon: TRUCK_ICON, upcomingIcon: HOME_ICON })),
  );
  protected readonly itemCount = computed(() => this.shipment()?.items.length ?? 0);
  /**
   * The Live Route GPS Tracking card, Live Map View button and current-location line are shown (as in the design) for
   * every shipment that is not cancelled, failed or returned. They show live details only when the API sends them.
   */
  // CHANGED: they were shown only with live location data, which the tracking API does not send yet.
  protected readonly showLiveTracking = computed(() => !!this.shipment() && !this.closedNote());
  /** The current location the API sent ('' when none). */
  // CHANGED (new)
  protected readonly currentLocation = computed(() => this.shipment()?.currentLocation?.trim() ?? '');
  /**
   * Without a current location, the location line says where the package is in the delivery instead: the shipping
   * status ("In Transit", from ORDER_SHIPPING_STATUS_NAME) and, once it is shipped, the carrier it is with.
   */
  // CHANGED (new)
  protected readonly packageStatus = computed(() => {
    const shipment = this.shipment();
    const status = shipment?.shippingStatus?.trim() ?? '';
    if (!shipment || !status) return null;
    const stage = shipmentStage(status);
    return {
      status: shippingStatusLabel(status),
      carrier: stage !== null && stage >= 2 && stage < 5 ? shipment.carrier.name : '',
    };
  });
  /** True while Refresh loads the tracking details again. */
  // CHANGED (new)
  protected readonly refreshing = signal(false);
  /** Why the last Refresh failed ('' when it did not), shown in the map card. */
  // CHANGED (new)
  protected readonly refreshError = signal('');
  /** "Verified Packed": only once the shipping status is Packed or later. */
  // CHANGED (new): it was shown once the shipment had a shipping date.
  protected readonly verifiedPacked = computed(() => {
    const status = this.shipment()?.shippingStatus;
    const stage = status ? shipmentStage(status) : null;
    return stage !== null && stage >= 1;
  });
  /** The note shown instead of the progress steps for a cancelled, failed or returned order. */
  // CHANGED (new)
  protected readonly closedNote = computed(() => {
    const shipment = this.shipment();
    return CLOSED_STATUS_NOTES[statusKey(shipment?.orderStatus)] ?? CLOSED_STATUS_NOTES[statusKey(shipment?.shippingStatus)];
  });

  protected readonly copied = signal(false);
  protected readonly notice = signal('');
  protected readonly returnRequestOpen = signal(false);
  protected readonly returnReason = signal<number | null>(null);
  protected readonly returnReasonValue = computed(() => {
    const reasonId = this.returnReason();
    return reasonId === null ? '' : String(reasonId);
  });
  protected readonly returnDetails = signal('');
  // CHANGED: the limit is the service's (the request is checked against it too).
  protected readonly returnDetailsMaxLength = RETURN_DESCRIPTION_MAX_LENGTH;
  protected readonly returnReasonError = signal(false);
  protected readonly returnReasons = signal<ReturnReasonOption[]>([]);
  protected readonly returnReasonsStatus = signal<'idle' | 'loading' | 'success' | 'error'>('idle');
  protected readonly returnReasonsError = signal('');
  /** Return Type: refund or replacement, a SHIPPING_STATUS_ID of a "RETURN/…" shipping status. */
  // CHANGED (new)
  protected readonly returnType = signal<number | null>(null);
  protected readonly returnTypeValue = computed(() => {
    const typeId = this.returnType();
    return typeId === null ? '' : String(typeId);
  });
  protected readonly returnTypeError = signal(false);
  protected readonly returnTypes = signal<StatusOption[]>([]);
  protected readonly returnTypesStatus = signal<'idle' | 'loading' | 'success' | 'error'>('idle');
  protected readonly returnTypesError = signal('');
  /** "RETURN/REFUND" -> "Return/Refund" (as the page shows its other shipping statuses). */
  protected readonly returnTypeLabel = shippingStatusLabel;
  /** The dropdowns' options: the API IDs as values. */
  // CHANGED (new): for SearchableSelect (the native select's list could not be styled and covered the dialog).
  protected readonly returnTypeOptions = computed<SearchableSelectOption[]>(() =>
    this.returnTypes().map((type) => ({ value: String(type.id), label: shippingStatusLabel(type.label) })),
  );
  protected readonly returnReasonOptions = computed<SearchableSelectOption[]>(() =>
    this.returnReasons().map((reason) => ({ value: String(reason.REASON_ID), label: reason.REASON })),
  );
  /** The order's products (one per order line of the tracking response), each with its own row's IDs. */
  // CHANGED (new): a return sends the IDs of the product chosen, never another product's.
  private readonly returnCandidates = computed(() => returnCandidates(this.shipment()?.items ?? []));
  /** Order lines already requested on this page ("<order number>|<line key>"). */
  private readonly requestedReturns = signal<ReadonlySet<string>>(new Set());
  /** The products the dialog offers: those not yet requested on this page. */
  protected readonly returnProducts = computed(() => {
    const requested = this.requestedReturns();
    const order = this.orderNumber();
    return this.returnCandidates().filter((candidate) => !requested.has(`${order}|${candidate.key}`));
  });
  protected readonly returnProductOptions = computed<SearchableSelectOption[]>(() =>
    this.returnProducts().map((candidate) => ({ value: candidate.key, label: candidate.label })),
  );
  /** The chosen product's line (the first product is chosen when the dialog opens). */
  protected readonly returnProductKey = signal('');
  private readonly selectedReturn = computed(() => {
    const products = this.returnProducts();
    return products.find((candidate) => candidate.key === this.returnProductKey()) ?? (products.length === 1 ? products[0] : null);
  });
  /** The product the dialog shows and the request returns. */
  // CHANGED: the chosen product (it was always the order's first).
  protected readonly returnItem = computed(() => this.selectedReturn()?.item ?? null);
  /** Every product of this order was requested on this page: Cancel / Return is then done. */
  // CHANGED (new)
  protected readonly allReturnsRequested = computed(
    () => this.returnCandidates().length > 0 && this.returnProducts().length === 0,
  );
  /** True while POST return_request is in flight: the form is locked and Submit shows its spinner. */
  // CHANGED (new)
  protected readonly submittingReturn = signal(false);
  protected readonly returnSubmitError = signal('');
  private readonly submittedReturn = signal<SubmittedReturn | null>(null);
  /** The latest return request made for this order on this page. */
  // CHANGED (new)
  protected readonly currentReturn = computed(() => {
    const submitted = this.submittedReturn();
    return submitted && submitted.orderNumber === this.orderNumber() ? submitted : null;
  });
  private readonly toast = inject(ToastService);
  private readonly timers: ReturnType<typeof setTimeout>[] = [];

  constructor() {
    this.destroyRef.onDestroy(() => this.timers.forEach(clearTimeout));
    // CHANGED (new): loads the order's tracking (again for another order number, and on "Try again").
    toObservable(computed(() => ({ orderNumber: this.orderNumber(), retry: this.retryCount() })))
      .pipe(
        switchMap(({ orderNumber }) => {
          this.shipment.set(null);
          this.error.set('');
          if (!orderNumber) {
            // No order number: nothing to load, so the page shows "not found".
            this.status.set('success');
            return EMPTY;
          }
          this.status.set('loading');
          return defer(() => this.orders.getShipmentTracking(orderNumber)).pipe(
            tap((shipment) => {
              this.shipment.set(shipment);
              this.status.set('success');
            }),
            catchError((error: unknown) => {
              const message = this.orders.customerOrdersErrorMessage(error, 'Shipment tracking');
              this.error.set(message);
              this.status.set('error');
              this.toast.showError(message);
              return EMPTY;
            }),
          );
        }),
        takeUntilDestroyed(),
      )
      .subscribe();
  }

  /** "Try again" after the tracking request failed. */
  // CHANGED (new)
  protected retry(): void {
    if (this.status() !== 'loading') this.retryCount.update((count) => count + 1);
  }

  /**
   * The map card's Refresh: requests the tracking details again (GET tracking; there is no live-tracking API or push
   * channel, so nothing polls) and shows what the API sends now, keeping the page as it is meanwhile. A failure keeps
   * the details shown and is reported in the map card and a toast.
   */
  // CHANGED (new)
  protected refreshTracking(): void {
    const orderNumber = this.orderNumber();
    if (!orderNumber || this.refreshing() || this.status() !== 'success') return;
    this.refreshing.set(true);
    this.refreshError.set('');
    this.orders
      .getShipmentTracking(orderNumber)
      .pipe(
        finalize(() => this.refreshing.set(false)),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (shipment) => {
          if (shipment) this.shipment.set(shipment);
        },
        error: (error: unknown) => {
          const message = this.orders.customerOrdersErrorMessage(error, 'Shipment tracking');
          this.refreshError.set(message);
          this.toast.showError(message);
        },
      });
  }

  protected showMap(): void {
    const map = this.document.getElementById('shipment-map');
    map?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    map?.focus({ preventScroll: true });
  }

  // CHANGED: also resets and loads the Return Type, and chooses the first product not yet requested; not offered
  // once every product of the order was requested.
  protected openReturnRequest(): void {
    if (this.allReturnsRequested()) return;
    this.returnProductKey.set(this.returnProducts()[0]?.key ?? '');
    this.returnType.set(null);
    this.returnTypeError.set(false);
    this.returnReason.set(null);
    this.returnDetails.set('');
    this.returnReasonError.set(false);
    this.returnSubmitError.set('');
    this.returnRequestOpen.set(true);
    this.loadReturnTypes();
    this.loadReturnReasons();
  }

  // CHANGED: stays open while the request is being sent.
  protected closeReturnRequest(): void {
    if (this.submittingReturn()) return;
    this.returnRequestOpen.set(false);
    this.returnTypeError.set(false);
    this.returnReasonError.set(false);
  }

  /** An order with several products: which one is returned (its IDs are the ones sent). */
  // CHANGED (new)
  protected setReturnProduct(value: string): void {
    this.returnProductKey.set(value);
    this.returnSubmitError.set('');
  }

  // CHANGED (new)
  protected setReturnType(value: string): void {
    this.returnType.set(selectedId(value));
    if (this.returnType() !== null) this.returnTypeError.set(false);
    this.returnSubmitError.set('');
  }

  // CHANGED: takes the dropdown's value (SearchableSelect emits it); same ID rule.
  protected setReturnReason(value: string): void {
    this.returnReason.set(selectedId(value));
    if (this.returnReason() !== null) this.returnReasonError.set(false);
    this.returnSubmitError.set('');
  }

  /**
   * The Return Type options: the "RETURN/…" shipping statuses (OrderService.getReturnTypes, from the shipping-status
   * list the tracking already loaded). A failed load offers Try again.
   */
  // CHANGED (new)
  protected loadReturnTypes(): void {
    const status = this.returnTypesStatus();
    if (status === 'loading' || status === 'success') return;

    this.returnTypesStatus.set('loading');
    this.returnTypesError.set('');
    this.orders
      .getReturnTypes()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (types) => {
          this.returnTypes.set(types);
          this.returnTypesStatus.set('success');
        },
        error: (error: unknown) => {
          // As for the reasons: the API's own failure message, else a generic one (not raw HTTP details).
          const message =
            error instanceof Error && error.message ? error.message : 'Return types could not be loaded. Please try again.';
          this.returnTypesError.set(message);
          this.returnTypesStatus.set('error');
          this.toast.showError(message);
        },
      });
  }

  protected loadReturnReasons(): void {
    const status = this.returnReasonsStatus();
    if (status === 'loading' || status === 'success') return;

    this.returnReasonsStatus.set('loading');
    this.returnReasonsError.set('');
    this.orders
      .getReturnReasons()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (reasons) => {
          this.returnReasons.set(reasons);
          this.returnReasonsStatus.set('success');
        },
        error: (error: unknown) => {
          const message =
            error instanceof HttpErrorResponse
              ? 'Return reasons could not be loaded. Please try again.'
              : error instanceof Error
                ? error.message
                : 'Return reasons could not be loaded. Please try again.';
          this.returnReasonsError.set(message);
          this.returnReasonsStatus.set('error');
          this.toast.showError(message);
        },
      });
  }

  protected setReturnDetails(event: Event): void {
    this.returnDetails.set((event.target as HTMLTextAreaElement).value.slice(0, RETURN_DESCRIPTION_MAX_LENGTH));
  }

  /**
   * Submit: the Return Type and the reason are required. POST return_request then sends `{ ORDER_NUMBER, REASON_ID,
   * RETURN_DESCRIPTION, RETURN_OPTION, PRODUCT_ID, VARIANT_ID, SELLER_ID, PICKUP_ADDRESS_ID }`, one request at a time:
   * RETURN_OPTION is the chosen Return Type (SHIPPING_STATUS_ID), REASON_ID the chosen reason, and every other ID comes
   * from the chosen product's own tracking row (PRODUCT_ID, PRODUCT_VARIANT_ID, SELLER_ID, DELIVERY_ADDRESS_ID as the
   * pickup address). A product whose row lacks one of them is not sent. On success the dialog closes, a toast and the
   * page confirm the request with the status the API gave it, that product is not offered again, and the tracking
   * details are read again (the order's status may have changed). On failure the dialog stays open with the reason.
   */
  // CHANGED: sends the request (it only showed a notice).
  // CHANGED: the backend contract's full body, with the IDs of the chosen product's tracking row (no other lookups).
  protected submitReturnRequest(event: Event): void {
    event.preventDefault();
    if (this.submittingReturn()) return;
    const typeId = this.returnType();
    const reasonId = this.returnReason();
    this.returnTypeError.set(typeId === null);
    this.returnReasonError.set(reasonId === null);
    const orderNumber = this.orderNumber();
    if (typeId === null || reasonId === null || !orderNumber) return;
    const selected = this.selectedReturn();
    const item = selected?.item;
    const { productId, variantId, sellerId, deliveryAddressId } = item ?? {};
    if (!selected || productId === undefined || variantId === undefined || sellerId === undefined) {
      this.returnSubmitError.set('This product could not be identified, so it cannot be returned here. Please refresh the page and try again.');
      return;
    }
    // The product was delivered there, so it is picked up there.
    if (deliveryAddressId === undefined) {
      this.returnSubmitError.set('The pickup address of this order could not be found, so it cannot be returned here.');
      return;
    }

    const typeLabel = shippingStatusLabel(this.returnTypes().find((type) => type.id === typeId)?.label ?? '');
    const reasonLabel = this.returnReasons().find((reason) => reason.REASON_ID === reasonId)?.REASON ?? '';
    this.submittingReturn.set(true);
    this.returnSubmitError.set('');
    this.orders
      .createReturnRequest({
        ORDER_NUMBER: this.shipment()?.orderId || orderNumber,
        REASON_ID: reasonId,
        RETURN_DESCRIPTION: this.returnDetails(),
        RETURN_OPTION: typeId,
        PRODUCT_ID: productId,
        VARIANT_ID: variantId,
        SELLER_ID: sellerId,
        PICKUP_ADDRESS_ID: deliveryAddressId,
      })
      .pipe(
        finalize(() => this.submittingReturn.set(false)),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (result) => {
          this.requestedReturns.update((requested) => new Set(requested).add(`${orderNumber}|${selected.key}`));
          this.submittedReturn.set({ orderNumber, result, productName: selected.item.name, typeLabel, reasonLabel });
          this.toast.showSuccess(result.message);
          this.submittingReturn.set(false);
          this.closeReturnRequest();
          this.refreshTracking();
        },
        error: (error: unknown) => {
          const message = this.orders.returnRequestErrorMessage(error);
          this.returnSubmitError.set(message);
          this.toast.showError(message);
        },
      });
  }

  protected async copyTrackingNo(): Promise<void> {
    const trackingNo = this.shipment()?.carrier.trackingNo;
    if (!trackingNo) return;
    try {
      await navigator.clipboard.writeText(trackingNo);
      this.copied.set(true);
      this.timers.push(setTimeout(() => this.copied.set(false), COPIED_RESET_MS));
    } catch {
      this.notice.set('Could not copy the tracking number. Please copy it manually.');
    }
  }

  // CHANGED: downloadInvoice() is removed: Invoice PDF is now a link to the shipment's actions.invoiceUrl, shown only
  // when the backend sends one (there is no invoice API yet).
}
