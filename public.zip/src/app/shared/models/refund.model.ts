export type RefundStatus = 'Completed' | 'Processing';

export interface RefundItem {
  name: string;
  variant: string;
  quantity: number;
  price: number;
  returnReason: string;
}

export interface Refund {
  /** Return number; also the route id (`/refund/:id`). */
  id: string;
  orderNo: string;
  amount: number;
  status: RefundStatus;
  /** Shown as "Credited via ...". */
  creditedVia: string;
  /** Payment instrument, e.g. "Visa ending in 4242". */
  method: string;
  reference: string;
  /** ISO date the refund was processed. */
  processedOn: string;
  /** Zero-based index of the current lifecycle step (see REFUND_STEPS on the refund page). */
  stage: number;
  items: RefundItem[];
}

export interface ReturnRequestsQuery {
  DAYS: number;
  RETURN_STATUS: number;
  RETURN_REASON: number;
  LIMIT: number;
  OFFSET: number;
}

/** Seller login: `return_request/get?SELLER_ID=…&LIMIT=…&OFFSET=…` (no day/status/reason filters). */
// CHANGED (new): query for the Seller variant of the Return Request listing.
export interface SellerReturnRequestsQuery {
  SELLER_ID: number;
  LIMIT: number;
  OFFSET: number;
}

export interface ReturnRequestRow {
  returnId: number;
  orderId: number | null;
  orderNumber: string | null;
  productId: number | null;
  productName: string | null;
  quantity: number | null;
  reason: string | null;
  description: string | null;
  images: string[];
  pickupAddressId: number | null;
  address: string | null;
  sellerId: number | null;
  customerId: number | null;
  customerName: string | null;
  customerMobile: string | null;
  variantId: number | null;
  /** The status name (RETURN_STATUS_NAME, else a text RETURN_STATUS); may be an ID when the API sends only that. */
  status: string | null;
  createdAt: string | null;
  /**
   * CHANGED (new): IDs for the Admin screen, each null when the API does not send it: the return status
   * (RETURN_STATUS_ID, or a numeric RETURN_STATUS; an ID of the all_status/get list), the return reason
   * (RETURN_REASON_ID / REASON_ID), and the return type chosen by the customer (RETURN_OPTION: the SHIPPING_STATUS_ID
   * of RETURN/REFUND or RETURN/REPLACE) with its name when sent (RETURN_OPTION_NAME). sellerName is SELLER_NAME /
   * BUSINESS_NAME when sent.
   */
  statusId: number | null;
  reasonId: number | null;
  returnOptionId: number | null;
  returnOptionName: string | null;
  sellerName: string | null;
}

export interface ReturnRequestsPage {
  requests: ReturnRequestRow[];
  totalRecords: number;
}

// CHANGED: ReturnRequestStatusUpdate (`{ RETURN_ID, RETURN_STATUS: 'APPROVED' | 'REJECTED' }`) is removed: the backend
// refuses that body. Approve / Reject send ReturnRequestReview below.

/** The Admin's decision on a return request (also the status it leads to: Approved / Rejected). */
// CHANGED (new)
export type ReturnDecision = 'APPROVED' | 'REJECTED';

/**
 * Request body of Approve / Reject (PUT return_request/update), from the Return Request screen's row menu and details:
 * the request's ID, a return status ID, and ACTION, the decision.
 */
// CHANGED (new)
// CHANGED: ACTION is APPROVED / REJECTED (it was APPROVE / REJECT).
export interface ReturnRequestReview {
  RETURN_ID: number;
  RETURN_STATUS: number;
  ACTION: ReturnDecision;
}

/**
 * Request body for POST return_request (the customer's Cancel / Return Item). Field names match the backend
 * contract exactly; the access token identifies the customer. One request returns one product of the order.
 */
// CHANGED (new)
// CHANGED: the backend contract's full body (RETURN_OPTION, PRODUCT_ID, VARIANT_ID, SELLER_ID, PICKUP_ADDRESS_ID).
export interface ReturnRequestInsert {
  ORDER_NUMBER: string;
  /** REASON_ID from return_reason/get. */
  REASON_ID: number;
  /** The customer's additional details ('' when none were given). */
  RETURN_DESCRIPTION: string;
  /** The Return Type: SHIPPING_STATUS_ID of RETURN/REFUND or RETURN/REPLACE (shipping_status/get). */
  RETURN_OPTION: number;
  /** PRODUCT_ID, VARIANT_ID (PRODUCT_VARIANT_ID), SELLER_ID and PICKUP_ADDRESS_ID (DELIVERY_ADDRESS_ID) all come
   * from the returned product's own tracking row. VARIANT_ID is null for a product ordered without a variant. */
  PRODUCT_ID: number;
  VARIANT_ID: number | null;
  SELLER_ID: number;
  PICKUP_ADDRESS_ID: number;
}

/**
 * POST return_request's answer (`{ STATUS, ORDER_NUMBER, RETURN_REASON_ID, RETURN_REASON, RETURN_REQUEST_COUNT,
 * RETURN_STATUS_ID, RETURN_STATUS_NAME }`). A field the API leaves out is null.
 */
// CHANGED (new)
export interface ReturnRequestResult {
  orderNumber: string | null;
  reasonId: number | null;
  reason: string | null;
  /** RETURN_REQUEST_COUNT: the return requests the order now has. */
  requestCount: number | null;
  statusId: number | null;
  /** RETURN_STATUS_NAME, e.g. "PENDING". */
  statusName: string | null;
  /** The API's message, or a default confirmation. */
  message: string;
}
