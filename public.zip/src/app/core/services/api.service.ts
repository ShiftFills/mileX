import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../config/api.config';

type QueryParams = Record<string, string | number | boolean>;

/** Feature services talk to the backend through this, never through HttpClient directly. */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = inject(API_BASE_URL);

  get<T>(path: string, params?: QueryParams): Observable<T> {
    return this.http.get<T>(this.url(path), { params: new HttpParams({ fromObject: params }) });
  }

  post<T>(path: string, body: unknown): Observable<T> {
    return this.http.post<T>(this.url(path), body);
  }

  postText(path: string, body: unknown): Observable<string> {
    return this.http.post(this.url(path), body, {
      responseType: 'text',
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    });
  }

  put<T>(path: string, body: unknown): Observable<T> {
    return this.http.put<T>(this.url(path), body);
  }

  putText(path: string, body: unknown): Observable<string> {
    return this.http.put(this.url(path), body, {
      responseType: 'text',
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    });
  }

  delete<T>(path: string): Observable<T> {
    return this.http.delete<T>(this.url(path));
  }

  private url(path: string): string {
    return `${this.baseUrl.replace(/\/+$/, '')}/${path.replace(/^\/+/, '')}`;
  }
}
