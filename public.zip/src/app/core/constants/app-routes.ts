/** Single source of truth for URLs, so links and redirects never drift. */
export const APP_ROUTES = {
  home: '/',
  products: '/products',
  cart: '/cart',
  deliveryAddress: '/checkout/address',
  payment: '/checkout/payment',
  checkout: '/checkout',
  orders: '/orders',
  refund: '/refund',
  account: '/account',
  addresses: '/account/addresses',
  offers: '/offers',
  login: '/auth/login',
  register: '/auth/register',
  adminDashboard: '/admin/dashboard',
  addProduct: '/admin/products/new',
  allProducts: '/admin/products/all',
  sellerDashboard: '/seller/dashboard',
  sellerVerificationPending: '/seller/verification-pending',
  sellerRejected: '/seller/rejected',
  sellerOnboarding: '/seller/onboarding',
  sellerStatusUnavailable: '/seller/status-unavailable',
  wishlist: '/wishlist',
  support: '/help',
  sell: '/sell',
} as const;

/**
 * Query-string marker that opens the shared Login page in its seller variant
 * (`/auth/login?audience=seller`). It only changes the page copy and the register link;
 * authentication and role-based redirects are unchanged.
 */
export const SELLER_LOGIN_QUERY = { audience: 'seller' } as const;